package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.MonsterVO;

public class MonsterDao {
	private static MonsterDao instance = new MonsterDao();
	
	private MonsterDao() {}
	
	public static MonsterDao getInstance() {
		if(instance == null) {
			instance = new MonsterDao();
		}
		return instance;
	}
	
	public ArrayList<MonsterVO> getMonsterList(Connection conn, int level) throws SQLException{
		StringBuffer query = new StringBuffer();
		
		query.append(" SELECT					");
		query.append("		mon_num				");
		query.append("	  , mon_name 			");
		query.append("	  , mon_hp 				");
		query.append("	  , mon_atk 			");
		query.append("	  , mon_exp 			");
		query.append("	  , mon_money 			");
		query.append(" FROM						");
		query.append("		monster				");
		query.append(" WHERE 1=1				");
		query.append("	AND	mon_num <= ?		");
		
		PreparedStatement ps = conn.prepareStatement(query.toString());
		
		ps.setInt(1, level);
		
		ResultSet rs = ps.executeQuery();
		
		ArrayList<MonsterVO> result = new ArrayList<MonsterVO>();
		
		while(rs.next()) {
			MonsterVO temp = new MonsterVO();
			temp.setMonName(rs.getString("mon_name"));
			temp.setMonHp(rs.getInt("mon_hp"));
			temp.setMonAtk(rs.getInt("mon_atk"));
			temp.setMonExp(rs.getInt("mon_exp"));
			temp.setMonMoney(rs.getInt("mon_money"));
			temp.setMonNum(rs.getInt("mon_num"));
			result.add(temp);
		}
		
		if(ps!=null)ps.close();
		if(rs!=null)rs.close();
		
		return result;
	}
	
	public ArrayList<MonsterVO> getMonsterList2(Connection conn, int minLevel ,int maxLevel ) throws SQLException{
		StringBuffer query = new StringBuffer();
		
		query.append(" SELECT					");
		query.append("		mon_num				");
		query.append("	  , mon_name 			");
		query.append("	  , mon_hp 				");
		query.append("	  , mon_atk 			");
		query.append("	  , mon_exp 			");
		query.append("	  , mon_money 			");
		query.append(" FROM						");
		query.append("		monster				");
		query.append(" WHERE 1=1				");
		query.append("	AND	mon_num > ?			");
		query.append("	AND	mon_num < ?	");
		
		PreparedStatement ps = conn.prepareStatement(query.toString());
		
		ps.setInt(1, minLevel);
		ps.setInt(2, maxLevel);
		
		ResultSet rs = ps.executeQuery();
		
		ArrayList<MonsterVO> result = new ArrayList<MonsterVO>();
		
		while(rs.next()) {
			MonsterVO temp = new MonsterVO();
			temp.setMonName(rs.getString("mon_name"));
			temp.setMonHp(rs.getInt("mon_hp"));
			temp.setMonAtk(rs.getInt("mon_atk"));
			temp.setMonExp(rs.getInt("mon_exp"));
			temp.setMonMoney(rs.getInt("mon_money"));
			temp.setMonNum(rs.getInt("mon_num"));
			result.add(temp);
		}
		
		if(ps!=null)ps.close();
		if(rs!=null)rs.close();
		
		return result;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
