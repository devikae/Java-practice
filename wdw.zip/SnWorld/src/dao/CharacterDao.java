package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.AcountVO;
import model.CharacterVO;

public class CharacterDao {
	private static CharacterDao instance = new CharacterDao();

	private CharacterDao() {}

	public static CharacterDao getInstance() {
		if (instance == null) {
			instance = new CharacterDao();
		}
		return instance;
	}

	// 랭킹
	// 캐릭터VO 목록 레벨로 정렬해서 리턴
	public ArrayList<CharacterVO> levelList(Connection conn) throws SQLException {
		StringBuffer query = new StringBuffer();

		query.append("SELECT						");
		query.append("	    sta_level 				");
		query.append("	  , sta_hp 					");
		query.append("	  , sta_mp 					");
		query.append("	  , sta_atk					");
		query.append("	  , sta_job					");
		query.append("	  , sta_money				");
		query.append("	  , sta_acount				");
		query.append("	  , sta_name				");
		query.append("	  , sta_exp					");
		query.append("	  , sta_maxhp				");
		query.append("	  , sta_maxmp				");
		query.append("FROM							");
		query.append("		status					");
		query.append("ORDER BY						");
		query.append("		sta_level DESC		");

		PreparedStatement ps = conn.prepareStatement(query.toString());
		ResultSet rs = ps.executeQuery();

		ArrayList<CharacterVO> result = new ArrayList<CharacterVO>();

		while (rs.next()) {
			CharacterVO temp = new CharacterVO();

			temp.setLevel(rs.getInt("sta_level"));
			temp.setHp(rs.getInt("sta_hp"));
			temp.setMp(rs.getInt("sta_mp"));
			temp.setAtk(rs.getInt("sta_atk"));
			temp.setJob(rs.getInt("sta_job"));
			temp.setMoney(rs.getInt("sta_money"));
			temp.setAcountNM(rs.getInt("sta_acount"));
			temp.setName(rs.getString("sta_name"));
			temp.setExp(rs.getInt("sta_exp"));
			temp.setMaxHp(rs.getInt("sta_maxhp"));
			temp.setMaxMp(rs.getInt("sta_maxmp"));

			result.add(temp);
		}

		if (ps != null)
			ps.close();
		if (rs != null)
			rs.close();

		return result;
	}
	
	
	// 데이터 저장 
	public int saveStatus(Connection conn, CharacterVO cha) throws SQLException {
		StringBuffer query = new StringBuffer();
		
		query.append("UPDATE								");
		query.append("		status							");
		query.append("SET 									");
		query.append("    sta_level = ?						");
		query.append("  , sta_hp = ?						");
		query.append("  , sta_mp = ?						");
		query.append("  , sta_atk = ?						");
		query.append("  , sta_job = ?						");
		query.append("  , sta_money = ?						");
		query.append("  , sta_exp = ?						");
		query.append("  , sta_maxhp = ?						");
		query.append("  , sta_maxmp = ?						");
		query.append("WHERE 	1=1							");
		query.append("  AND sta_acount = ?					");
//		query.append("  AND sta_acount_num = ?				");// 학원
		
		PreparedStatement ps = conn.prepareStatement(query.toString());
		
		int idx = 1;
		
		ps.setInt(idx++, cha.getLevel());
		ps.setInt(idx++, cha.getHp());
		ps.setInt(idx++, cha.getMp());
		ps.setInt(idx++, cha.getAtk());
		ps.setInt(idx++, cha.getJob());
		ps.setInt(idx++, cha.getMoney());
		ps.setInt(idx++, cha.getExp());
		ps.setInt(idx++, cha.getMaxHp());
		ps.setInt(idx++, cha.getMaxMp());
		ps.setInt(idx++, cha.getAcountNM());
		
		int cnt = ps.executeUpdate();
		
		if(ps != null) ps.close();
		
		return cnt;
	}
	
	public CharacterVO getStatus(Connection conn, int acount) throws SQLException {
		StringBuffer query = new StringBuffer();
		
		query.append("SELECT								");
		query.append("    a.sta_level 						");
		query.append("  , a.sta_hp 							");
		query.append("  , a.sta_mp 							");
		query.append("  , a.sta_atk 						");
		query.append("  , a.sta_job 						");
		query.append("  , a.sta_money  						");
		query.append("  , a.sta_acount	 					");
		query.append("  , a.sta_name	 					");
		query.append("  , a.sta_exp 						");
		query.append("  , a.sta_maxhp 						");
		query.append("  , a.sta_maxmp 						");
		query.append(" FROM									");
		query.append("		status a						");
		query.append("		,acount b						");
		query.append("	WHERE			1=1					");
		query.append("	AND	 b.acount_num = a.sta_acount  	");
		query.append("	AND	 a.sta_acount = ?			 	");
//		query.append("  AND sta_acount_num = ?				");// 학원
		
		PreparedStatement ps = conn.prepareStatement(query.toString());
		
		ps.setInt(1, acount);
		
		ResultSet rs = ps.executeQuery();
		
		CharacterVO temp = new CharacterVO();
		
		while (rs.next()) {
			temp.setLevel(rs.getInt("sta_level"));
			temp.setHp(rs.getInt("sta_hp"));
			temp.setMp(rs.getInt("sta_mp"));
			temp.setAtk(rs.getInt("sta_atk"));
			temp.setJob(rs.getInt("sta_job"));
			temp.setMoney(rs.getInt("sta_money"));
			temp.setName(rs.getString("sta_name"));
			temp.setExp(rs.getInt("sta_exp"));
			temp.setMaxHp(rs.getInt("sta_maxhp"));
			temp.setMaxMp(rs.getInt("sta_maxmp"));
			temp.setAcountNM(rs.getInt("sta_acount"));
		}
		
		
		if (ps != null)
			ps.close();
		if (rs != null)
			rs.close();
		
		return temp;
		
	}
	
	public int registStatus(Connection conn, CharacterVO cha) throws SQLException {

		StringBuffer query = new StringBuffer();
		
		query.append("INSERT INTO						");
		query.append("			status					");
		query.append("VALUES (							");
		query.append("		  ?							");
		query.append("		, ?							");
		query.append("		, ?							");
		query.append("		, ?							");
		query.append("		, ?							");
		query.append("		, ?							");
		query.append("		, ?							");
		query.append("		, ?							");
		query.append("		, ?							");
		query.append("		, ?							");
		query.append("		, ?							");
		query.append("		)							");
		
		PreparedStatement ps = conn.prepareStatement(query.toString());
		
		CharacterVO temp = new CharacterVO();
		System.out.println(cha.getAcountNM());
		int idx = 1;
		ps.setInt(idx++, cha.getLevel()); //
		ps.setInt(idx++, cha.getHp());		//
		ps.setInt(idx++, cha.getMp());		//
		ps.setInt(idx++, cha.getAtk());		//
		ps.setInt(idx++, cha.getJob());		//
		ps.setInt(idx++, cha.getMoney());	//
		ps.setInt(idx++, cha.getAcountNM());	
		ps.setString(idx++, cha.getName());
		ps.setInt(idx++, cha.getExp());
		ps.setInt(idx++, cha.getMaxHp());
		ps.setInt(idx++, cha.getMaxMp());
		
		
		int cnt = ps.executeUpdate();
		
		if(ps!=null)ps.close();
		
		return cnt;
	}
	
	public int job1(Connection conn, CharacterVO cha) throws SQLException { // 전사 
		StringBuffer query = new StringBuffer();
		
		query.append("UPDATE								");
		query.append("		status							");
		query.append("SET 									");
		query.append("    sta_level = ?						");
		query.append("  , sta_hp = ?						");
		query.append("  , sta_mp = ?						");
		query.append("  , sta_atk = ?						");
		query.append("  , sta_job = ?						");
		query.append("  , sta_money = ?						");
		query.append("  , sta_exp = ?						");
		query.append("  , sta_maxhp = ?						");
		query.append("  , sta_maxmp = ?						");
		query.append("WHERE 	1=1							");
		query.append("  AND sta_acount = ?					");
//		query.append("  AND sta_acount_num = ?				");// 학원
		
		PreparedStatement ps = conn.prepareStatement(query.toString());
		
		int idx = 1;
		
		ps.setInt(idx++, cha.getLevel());
		ps.setInt(idx++, cha.getHp());
		ps.setInt(idx++, cha.getMp());
		ps.setInt(idx++, cha.getAtk());
		ps.setInt(idx++, 1);
		ps.setInt(idx++, cha.getMoney());
		ps.setInt(idx++, cha.getExp());
		ps.setInt(idx++, cha.getMaxHp());
		ps.setInt(idx++, cha.getMaxMp());
		ps.setInt(idx++, cha.getAcountNM());
		
		int cnt = ps.executeUpdate();
		
		if(ps != null) ps.close();
		
		return cnt;
	}
	
	public int job2(Connection conn, CharacterVO cha) throws SQLException { // 도적
		StringBuffer query = new StringBuffer();
		
		query.append("UPDATE								");
		query.append("		status							");
		query.append("SET 									");
		query.append("    sta_level = ?						");
		query.append("  , sta_hp = ?						");
		query.append("  , sta_mp = ?						");
		query.append("  , sta_atk = ?						");
		query.append("  , sta_job = ?						");
		query.append("  , sta_money = ?						");
		query.append("  , sta_exp = ?						");
		query.append("  , sta_maxhp = ?						");
		query.append("  , sta_maxmp = ?						");
		query.append("WHERE 	1=1							");
		query.append("  AND sta_acount = ?					");
//		query.append("  AND sta_acount_num = ?				");// 학원
		
		PreparedStatement ps = conn.prepareStatement(query.toString());
		
		int idx = 1;
		
		ps.setInt(idx++, cha.getLevel());
		ps.setInt(idx++, cha.getHp());
		ps.setInt(idx++, cha.getMp());
		ps.setInt(idx++, cha.getAtk());
		ps.setInt(idx++, 2);
		ps.setInt(idx++, cha.getMoney());
		ps.setInt(idx++, cha.getExp());
		ps.setInt(idx++, cha.getMaxHp());
		ps.setInt(idx++, cha.getMaxMp());
		ps.setInt(idx++, cha.getAcountNM());
		
		int cnt = ps.executeUpdate();
		
		if(ps != null) ps.close();
		
		return cnt;
	}
	
	public int job3(Connection conn, CharacterVO cha) throws SQLException { // 마법사
		StringBuffer query = new StringBuffer();
		
		query.append("UPDATE								");
		query.append("		status							");
		query.append("SET 									");
		query.append("    sta_level = ?						");
		query.append("  , sta_hp = ?						");
		query.append("  , sta_mp = ?						");
		query.append("  , sta_atk = ?						");
		query.append("  , sta_job = ?						");
		query.append("  , sta_money = ?						");
		query.append("  , sta_exp = ?						");
		query.append("  , sta_maxhp = ?						");
		query.append("  , sta_maxmp = ?						");
		query.append("WHERE 	1=1							");
		query.append("  AND sta_acount = ?					");
//		query.append("  AND sta_acount_num = ?				");// 학원
		
		PreparedStatement ps = conn.prepareStatement(query.toString());
		
		int idx = 1;
		
		ps.setInt(idx++, cha.getLevel());
		ps.setInt(idx++, cha.getHp());
		ps.setInt(idx++, cha.getMp());
		ps.setInt(idx++, cha.getAtk());
		ps.setInt(idx++, 3);
		ps.setInt(idx++, cha.getMoney());
		ps.setInt(idx++, cha.getExp());
		ps.setInt(idx++, cha.getMaxHp());
		ps.setInt(idx++, cha.getMaxMp());
		ps.setInt(idx++, cha.getAcountNM());
		
		int cnt = ps.executeUpdate();
		
		if(ps != null) ps.close();
		
		return cnt;
	}
	
	
	
	
	
}
