package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.AcountVO;
import model.CharacterVO;

public class AcountDao {
	
	private static AcountDao instance = new AcountDao();
	
	private AcountDao() {}
	
	public static AcountDao getInstance() {
		if(instance == null) {
			instance = new AcountDao();
		}
		return instance;
	}

	
	// 회원가입
	public int registAcount(Connection conn, String id, String pw, String name) throws SQLException {

		StringBuffer query = new StringBuffer();
		
		query.append("INSERT INTO						");
		query.append("			acount					");
		query.append("VALUES (							");
		query.append("		  ?							");
		query.append("		, ?							");
		query.append("		, acount_seq.NEXTVAL		");		// 회원가입 순서대로 seq_num		
		query.append("		, ?							");
		query.append("		)							");
		
		PreparedStatement ps = conn.prepareStatement(query.toString());
		
		AcountVO temp = new AcountVO(id, pw, name);
		
		int idx = 1;
		ps.setString(idx++, temp.getLoginID());	
		ps.setString(idx++, temp.getLoginPW());
//		ps.setInt(idx++, temp.getAcountNUM()); // 시퀀스로 만들기 때문에 필요없음
		ps.setString(idx++, temp.getAcountNM());
		
		int cnt = ps.executeUpdate();
		
		if(ps!=null)ps.close();
		
		return cnt;
	}
	
	
	// 회원가입할때, 입력한 아이디에 대한 중복체크
	// 로그인시, 입력한 아이디에 대한 패스워드 검사
	// 로그인 성공 시, 입력한 아이디에 대한 acount 데이터 가져옴
	public AcountVO getAcount(Connection conn, String id) throws SQLException {
		StringBuffer query = new StringBuffer();

		query.append("SELECT						");
		query.append("		login_id				");
		query.append("	  ,	login_pw	  			");
		query.append("	  ,	acount_num				");
		query.append("	  ,	acount_name	  			");
		query.append("FROM							");
		query.append("		acount					");
		query.append("WHERE 1=1					");
		query.append("	AND	 login_id = ?		");

		PreparedStatement ps = conn.prepareStatement(query.toString());
		ps.setString(1, id);

		ResultSet rs = ps.executeQuery();

		AcountVO temp = new AcountVO();

		while (rs.next()) {
			temp.setLoginID(rs.getString("login_id"));
			temp.setLoginPW(rs.getString("login_pw"));
			temp.setAcountNUM(rs.getInt("acount_num"));
			temp.setAcountNM(rs.getString("acount_name"));
		}

		if (ps != null)
			ps.close();
		if (rs != null)
			rs.close();

		return temp;
	}
	
	public int getAcountNUM(Connection conn, String id) throws SQLException {
		StringBuffer query = new StringBuffer();

		query.append("SELECT						");
		query.append("		login_id				");
		query.append("	  ,	login_pw	  			");
		query.append("	  ,	acount_num				");
		query.append("	  ,	acount_name	  			");
		query.append("FROM							");
		query.append("		acount					");
		query.append("WHERE 1=1					");
		query.append("	AND	 login_id = ?		");

		PreparedStatement ps = conn.prepareStatement(query.toString());
		ps.setString(1, id);

		ResultSet rs = ps.executeQuery();

		AcountVO temp = new AcountVO();
		

		while (rs.next()) {
			temp.setLoginID(rs.getString("login_id"));
			temp.setLoginPW(rs.getString("login_pw"));
			temp.setAcountNUM(rs.getInt("acount_num"));
			temp.setAcountNM(rs.getString("acount_name"));
		}
		

		if (ps != null)
			ps.close();
		if (rs != null)
			rs.close();

		return temp.getAcountNUM();
	}
	
	
	
	
	
	
}
