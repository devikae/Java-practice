package service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import connection.ConnectionPool;
import dao.CharacterDao;
import model.AcountVO;
import model.CharacterVO;

public class CharacterService {

	private static CharacterService instance = new CharacterService();
	private CharacterDao cDao = CharacterDao.getInstance();
	private ConnectionPool cp = ConnectionPool.getInstance();

	private CharacterService() {
	}

	public static CharacterService getInstance() {
		if (instance == null) {
			instance = new CharacterService();
		}

		return instance;
	}

	public ArrayList<CharacterVO> levelList() {
		Connection conn = cp.getConnection();
		try {
			return cDao.levelList(conn);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null)
				cp.releaseConnection(conn);
		}

		return new ArrayList<CharacterVO>();
	}

	public int saveStatus(CharacterVO cha) {
		Connection conn = cp.getConnection();

		try {
			return cDao.saveStatus(conn, cha);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null)
				cp.releaseConnection(conn);
		}

		return 0;
	}

	public CharacterVO getStatus(int acount) {
		Connection conn = cp.getConnection();
		try {
			return cDao.getStatus(conn, acount);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null)
				cp.releaseConnection(conn);
		}

		return new CharacterVO();
	}

	public int registStatus(CharacterVO cha) {
		Connection conn = cp.getConnection();

		try {
			return cDao.registStatus(conn, cha);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null)
				cp.releaseConnection(conn);
		}

		return 0;
	}

	public void getJob(CharacterVO cha, int job) {

		if (job == 1) {
			System.out.println(
					"==================================================================================================");
			System.out.println("                            축하합니다. \"전사\"로 전직했습니다.");
			System.out.println(" 1. 레벨업 시 공격력과 MaxHp가 증가 합니다.");
			System.out.println(" 2. 레벨을 올리면 스킬을 얻을 수 있습니다.");
			System.out.println(
					"==================================================================================================");
		} else if (job == 2) {
			System.out.println("\n\n\n\n");
			System.out.println(
					"==================================================================================================");
			System.out.println("                            축하합니다. \"도적\"으로 전직했습니다.");
			System.out.println(" 1. 레벨업 시 공격력이 증가 합니다.");
			System.out.println(" 2. 레벨을 올리면 스킬을 얻을 수 있습니다.");
			System.out.println(
					"==================================================================================================");
		} else if (job == 3) {
			System.out.println("\n\n\n\n");
			System.out.println(
					"==================================================================================================");
			System.out.println("                            축하합니다. \"마법사\"로 전직했습니다.");
			System.out.println(" 1. 레벨업 시 공격력과 maxMp가 증가 합니다.");
			System.out.println(" 2. 레벨을 올리면 스킬을 얻을 수 있습니다.");
			System.out.println(
					"==================================================================================================");
		}

	}

	public void levelUp(CharacterVO cha) { // 레벨업 시

		// 직업별로 다른 성장

		if (cha.getJob() == 0) { // 초보자 일 때
			System.out.println("\n★★★★★★★★★레벨업★★★★★★★★★");
			cha.setLevel(cha.getLevel() + 1);
			cha.setMaxHp(cha.getMaxHp() + 20);
			cha.setHp(cha.getMaxHp()); // 레벨업 시 현재체력 채워주기
			cha.setMaxMp(cha.getMaxMp() + 10);
			cha.setMp(cha.getMaxMp());
			cha.setAtk(cha.getAtk() + 5);
			

		} else if (cha.getJob() == 1) { // 전사일 때 특성 maxHp
			System.out.println("\n★★★★★★★★★레벨업★★★★★★★★★");
			cha.setLevel(cha.getLevel() + 1); // 레벨업 현재레벨 + 1
			cha.setMaxHp(cha.getMaxHp() + 50);
			cha.setHp(cha.getMaxHp());
			cha.setMaxMp(cha.getMaxMp() + 10);
			cha.setMp(cha.getMaxMp());
			cha.setAtk(cha.getAtk() + 10);
			cha.setJob(1);

		} else if (cha.getJob() == 2) { // 도적일 때 Atk
			System.out.println("\n★★★★★★★★★레벨업★★★★★★★★★");
			cha.setLevel(cha.getLevel() + 1);
			cha.setMaxHp(cha.getMaxHp() + 30);
			cha.setHp(cha.getMaxHp());
			cha.setMaxMp(cha.getMaxMp() + 10);
			cha.setMp(cha.getMaxMp());
			cha.setAtk(cha.getAtk() + 25);
			cha.setJob(2);

		} else if (cha.getJob() == 3) { // 마법사 일 때 maxMp
			System.out.println("\n★★★★★★★★★레벨업★★★★★★★★★");
			cha.setLevel(cha.getLevel() + 1);
			cha.setMaxHp(cha.getMaxHp() + 30);
			cha.setHp(cha.getMaxHp());
			cha.setMaxMp(cha.getMaxMp() + 50);
			cha.setMp(cha.getMaxMp());
			cha.setAtk(cha.getAtk() + 5);
			cha.setJob(3);
		}

	}

	public int job1(CharacterVO cha) {
		Connection conn = cp.getConnection();

		try {
			return cDao.job1(conn, cha);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null)
				cp.releaseConnection(conn);
		}

		return 0;
	}

	public int job2(CharacterVO cha) {
		Connection conn = cp.getConnection();

		try {
			return cDao.job2(conn, cha);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null)
				cp.releaseConnection(conn);
		}

		return 0;
	}

	public int job3(CharacterVO cha) {
		Connection conn = cp.getConnection();

		try {
			return cDao.job3(conn, cha);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null)
				cp.releaseConnection(conn);
		}

		return 0;
	}

	public void buyHp(CharacterVO cha, int price, int stat) {

		if (cha.getMoney() >= price) {
			cha.setMoney(cha.getMoney() - price);
			cha.setMaxHp(cha.getMaxHp() + stat);

			System.out.println("============================================");
			System.out.println(cha.getName() + "님의 MaxHp 가"+stat+" 증가 했습니다.");
			System.out.println("============================================");
		} else if (cha.getMoney() < price) {
			System.out.println("===================");
			System.out.println("돈이 부족합니다.");
			System.out.println("===================");
		}

	}

	public void buyMp(CharacterVO cha, int price, int stat) {

		if (cha.getMoney() >= price) {
			cha.setMoney(cha.getMoney() - price);
			cha.setMaxMp(cha.getMaxMp() + stat);
			System.out.println("============================================");
			System.out.println(cha.getName() + "님의 MaxMp 가" +stat +" 증가 했습니다.");
			System.out.println("============================================");
		} else if (cha.getMoney() < 100000) {
			System.out.println("===================");
			System.out.println("돈이 부족합니다.");
			System.out.println("===================");
		}

	}
	
	public void buyAtk(CharacterVO cha, int price, int stat) {

		if (cha.getMoney() >= price) {
			cha.setMoney(cha.getMoney() - price);
			cha.setAtk(cha.getAtk() + stat);
			System.out.println("============================================");
			System.out.println(cha.getName() + "님의 공격력이 " +stat +" 증가 했습니다.");
			System.out.println("============================================");
		} else if (cha.getMoney() < price) {
			System.out.println("===================");
			System.out.println("돈이 부족합니다.");
			System.out.println("===================");
		}

	}
	
	public void shop(CharacterVO cha) {
		
		if(cha.getLevel() <= 11) {
			System.out.println("	메뉴를 선택해주세요.");
			System.out.println("┏━━━━━━━━━━━━━━━━━━━━━━━┓");
			System.out.println("┃1.MaxHp + 50 |     500 ┃ ");
			System.out.println("┃2.MaxMp + 50 |     500 ┃ ");
			System.out.println("┃3.ATK   + 10 |     500 ┃ ");
			System.out.println("┃4.exit       |         ┃ ");
			System.out.println("┖━━━━━━━━━━━━━━━━━━━━━━━┚");
			
		}else if(cha.getLevel() < 31) {
			System.out.println("	메뉴를 선택해주세요.");
			System.out.println("┏━━━━━━━━━━━━━━━━━━━━━━━┓");
			System.out.println("┃1.MaxHp + 80 |  10,000 ┃ ");
			System.out.println("┃2.MaxMp + 80 |  10,000 ┃ ");
			System.out.println("┃3.ATK   + 30 |  10,000 ┃ ");
			System.out.println("┃4.exit       |         ┃ ");
			System.out.println("┖━━━━━━━━━━━━━━━━━━━━━━━┚");
			
		}else if(cha.getLevel() < 41) {
			System.out.println("	메뉴를 선택해주세요.");
			System.out.println("┏━━━━━━━━━━━━━━━━━━━━━━━┓");
			System.out.println("┃1.MaxHp +150 | 100,000 ┃ ");
			System.out.println("┃2.MaxMp +150 | 100,000 ┃ ");
			System.out.println("┃3.ATK   + 70 | 100,000 ┃ ");
			System.out.println("┃4.exit       |         ┃ ");
			System.out.println("┖━━━━━━━━━━━━━━━━━━━━━━━┚");
			
		}else if(cha.getLevel() <= 50) {
			System.out.println("	메뉴를 선택해주세요.");
			System.out.println("┏━━━━━━━━━━━━━━━━━━━━━━━┓");
			System.out.println("┃1.MaxHp +300 | 200,000 ┃ ");
			System.out.println("┃2.MaxMp +300 | 200,000 ┃ ");
			System.out.println("┃3.ATK   +100 | 200,000 ┃ ");
			System.out.println("┃4.exit       |         ┃ ");
			System.out.println("┖━━━━━━━━━━━━━━━━━━━━━━━┚");
			
		}else if(cha.getLevel() > 50) {
			System.out.println("	메뉴를 선택해주세요.");
			System.out.println("┏━━━━━━━━━━━━━━━━━━━━━━━┓");
			System.out.println("┃1.MaxHp +700 | 500,000 ┃ ");
			System.out.println("┃2.MaxMp +700 | 500,000 ┃ ");
			System.out.println("┃3.ATK   +500 | 500,000 ┃ ");
			System.out.println("┃4.exit       |         ┃ ");
			System.out.println("┖━━━━━━━━━━━━━━━━━━━━━━━┚");
		}
		
		
	}
	
	
	
	

}
