package service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import connection.ConnectionPool;
import dao.AcountDao;
import model.AcountVO;

public class AcountService {
	
	private static AcountService instance = new AcountService();
	private AcountDao aDao = AcountDao.getInstance();
	private ConnectionPool cp = ConnectionPool.getInstance();
	
	private AcountService() {}
	
	public static AcountService getInstance() {
		if(instance == null) {
			instance = new AcountService();
		}
		
		return instance;
	}
	
	
	public AcountVO getAcount(String id) {
		Connection conn = cp.getConnection();
		try {
			return aDao.getAcount(conn, id);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null)
				cp.releaseConnection(conn);
		}

		return new AcountVO();
	}		
	
	
	public int registAcount(String id, String pw, String name) {
		Connection conn = cp.getConnection();
		
		try {
			return aDao.registAcount(conn, id, pw, name);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(conn != null)cp.releaseConnection(conn);
		}
		
		return 0;
	}
	
	public int getAcountNUM(String id) {
		Connection conn = cp.getConnection();
		try {
			return aDao.getAcountNUM(conn, id);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null)
				cp.releaseConnection(conn);
		}

		return 1;
	}		
	
	
}
