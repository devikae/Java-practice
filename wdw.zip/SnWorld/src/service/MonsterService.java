package service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import connection.ConnectionPool;
import dao.MonsterDao;
import model.CharacterVO;
import model.MonsterVO;

public class MonsterService {
	private static MonsterService instance = new MonsterService();
	private MonsterDao dao = MonsterDao.getInstance();
	private ConnectionPool cp = ConnectionPool.getInstance();
	CharacterService cService = CharacterService.getInstance();
	
	public static MonsterService getInstance() {
		if(instance==null) {
			instance = new MonsterService();
		}
		return instance;
	}

// 사냥터에 따른 몬스터 배열 리턴 	
	public ArrayList<MonsterVO> getMonsterList(int level){
		Connection conn = cp.getConnection();
		
		try {
			return dao.getMonsterList(conn, level);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(conn != null) cp.releaseConnection(conn);
		}
		
		return new ArrayList<MonsterVO>();
	}
	
	public ArrayList<MonsterVO> getMonsterList2(int minLevel, int maxLevel){
		Connection conn = cp.getConnection();
		
		try {
			return dao.getMonsterList2(conn, minLevel, maxLevel);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(conn != null) cp.releaseConnection(conn);
		}
		
		return new ArrayList<MonsterVO>();
	}
	

	public void playBattle2(CharacterVO cha, ArrayList<MonsterVO> monster, int maxLevel, int maxExp, int still) {

		
		System.out.println(cha.getName() +" 이(가) 공격 했습니다.");
		monster.get(0).setMonHp(monster.get(0).getMonHp() - cha.getAtk());
		
		int amountExp = maxLevel*monster.get(0).getMonExp(); // 경험치 획득량 
	
		int amountLevel =(maxLevel * (cha.getLevel()+maxLevel)); 
		
		int amountMoney= maxLevel*monster.get(0).getMonMoney();
		
		int expState = (int) (((double)cha.getExp()/amountLevel)*100); // 경험치 비율
		
		if(monster.get(0).getMonHp() <= 0) { // 처치 했을 때 
			System.out.println(monster.get(0).getMonName() + " 을(를) 처치 했습니다.");
			cha.setExp(cha.getExp() + amountExp);
			cha.setMoney(cha.getMoney() + amountMoney);
			System.out.println("========================");
			System.out.println("경험치: "+ (amountExp) + ", 돈: "+ (amountMoney)+" 원 획득");
			expState(expState);
			System.out.println("========================");
			
			if(amountExp + cha.getExp() >= amountLevel) {
				amountLevel += maxExp; 
				cService.levelUp(cha);
				cha.setExp(0);
				cService.saveStatus(cha);
				System.out.println(cha.toStatus()+"\n"); 
				
				
			}
			
			cService.saveStatus(cha);
			
		}else if(monster.get(0).getMonHp() > 0) { // 처치 못 했을 때
			System.out.println(monster.get(0).toString());
			System.out.println(monster.get(0).getMonName() +" 이(가) 공격했습니다.");
			cha.setHp(cha.getHp() -monster.get(0).getMonAtk());
			System.out.println("========================");
			System.out.println("현재 체력: " + cha.getHp());
			System.out.println("========================");
			cService.saveStatus(cha);
			playBattle2(cha, monster, maxLevel, maxExp, still); //재귀함수 이용 

			if(cha.getHp() <= 0) { // 사망 시 패널티 
				System.out.println("캐릭터가 사망했습니다.");
				System.out.println("초원 몬스터들에게 "+still+"원을 강탈 당했습니다.");
				if(cha.getMoney() >still) {
					cha.setMoney(cha.getMoney() - still);
					
				}else if(cha.getMoney() <still) { 
					cha.setMoney(0);
					
				}
				
			}
			
		
	}

}
	
	public void playBattle1(CharacterVO cha, ArrayList<MonsterVO> monster, int maxLevel) {
		System.out.println(cha.getName() +" 이(가) 공격 했습니다.");
		monster.get(0).setMonHp(monster.get(0).getMonHp() - cha.getAtk());
		
		int amountExp = maxLevel*monster.get(0).getMonExp(); // 경험치 획득량 
	
		int amountLevel =(maxLevel * (cha.getLevel()+maxLevel)) *2; 
		
		int amountMoney= maxLevel*monster.get(0).getMonMoney();
		
		
		if(monster.get(0).getMonHp() <= 0) { // 처치 했을 때 
			System.out.println(monster.get(0).getMonName() + " 을(를) 처치 했습니다.");
			cha.setExp(cha.getExp() + amountExp);
			int expState = (int) (((double)cha.getExp()/amountLevel)*100); // 경험치 비율
			cha.setMoney(cha.getMoney() + amountMoney);
			System.out.println("========================");
			System.out.println("경험치: "+ (amountExp) + ", 돈: "+ (amountMoney)+" 원 획득");
			expState(expState);
			System.out.println("========================");
			
			if(amountExp + cha.getExp() >= amountLevel) {
				amountLevel += 100; 
				cService.levelUp(cha);
				cha.setExp(0);
				cService.saveStatus(cha);
				System.out.println(cha.toStatus()+"\n"); 
				
				if(cha.getLevel() == 10) {
					Scanner sc = new Scanner(System.in);
					System.out.println("==================================================================================================");
					System.out.println("           축하합니다 레벨 10을 찍어서 전직 할 수 있습니다. ");
					System.out.println("|1. 전사 | 2. 도적 | 3. 마법사 | 선택 하고 입력 해주세요. ");
					System.out.println("==================================================================================================");
					System.out.print(">>> ");
				
					int select = 0;

					try {
						select = Integer.parseInt(sc.nextLine());
					} catch (Exception e) {
						System.out.println("재시작 해주세요");
					}
					if(select ==1) { // 전사 전직
						cService.job1(cha);
						cService.getJob(cha, 1);
						cService.saveStatus(cha);
						
					}else if(select == 2) { // 도적
						cService.job2(cha);
						cService.getJob(cha, 2);
						cService.saveStatus(cha);
						
					}else if (select == 3) { // 마법사 
						cService.job3(cha);
						cService.getJob(cha, 3);
						cService.saveStatus(cha);
						
					}
					
				}
			}
			
			cService.saveStatus(cha);
			
		}else if(monster.get(0).getMonHp() > 0) { // 처치 못 했을 때
			System.out.println(monster.get(0).toString());
			System.out.println(monster.get(0).getMonName() +" 이(가) 공격했습니다.");
			cha.setHp(cha.getHp() -monster.get(0).getMonAtk());
			System.out.println("========================");
			System.out.println("현재 체력: " + cha.getHp());
			System.out.println("========================");
			cService.saveStatus(cha);
			playBattle1(cha, monster, 10); //재귀함수 이용 

			if(cha.getHp() <= 0) { // 사망 시 패널티 
				System.out.println("캐릭터가 사망했습니다.");
				System.out.println("초원 몬스터들에게 500원을 강탈 당했습니다.");
				if(cha.getMoney() >500) {
					cha.setMoney(cha.getMoney() - 500);
					
				}else if(cha.getMoney() <500) { // 가진돈이 500원보다 적다면
					cha.setMoney(0);
					
				}
				
			}
			
		
	}

}
	
public void playSkill(CharacterVO cha, ArrayList<MonsterVO> monster, int maxLevel, int maxExp, int still, int mana,
		int skill) {

	int amountExp = maxLevel * monster.get(0).getMonExp();

	int amountLevel = (maxLevel * (cha.getLevel() + maxLevel));

	int amountMoney = maxLevel * monster.get(0).getMonMoney();

	int expState = (int) (((double) cha.getExp() / amountLevel) * 100); // 경험치 비율

	if (skill == 1 && cha.getJob() == 1) {
		if (cha.getMp() >= mana) {
			System.out.println(cha.getName() + " 이(가) \"바람의 상처\"를 사용 했습니다.");
			monster.get(0).setMonHp(monster.get(0).getMonHp() - (cha.getAtk() + (cha.getHp() / 2)));
			cha.setMp(cha.getMp() - mana);
			System.out.println("			╃^─^─^─^─^─^─^─^─^─^─^─^╄");
			System.out.println("					"+cha.getAtk()+(cha.getHp()/2) );
			System.out.println("			╅───────────────────╆");
			
			if (monster.get(0).getMonHp() <= 0) { // 처치 했을 때
				System.out.println(monster.get(0).getMonName() + " 을(를) 처치 했습니다.");
				cha.setExp(cha.getExp() + amountExp);
				cha.setMoney(cha.getMoney() + amountMoney);
				System.out.println("========================");
				System.out.println("경험치: " + (amountExp) + ", 돈: " + (amountMoney) + " 원 획득");
				expState(expState);
				System.out.println("========================");

				if (amountExp + cha.getExp() >= amountLevel) {
					amountLevel += amountLevel+maxExp;
					cService.levelUp(cha);
					cha.setExp(0);
					cService.saveStatus(cha);
					System.out.println(cha.toStatus() + "\n");

				}
				cService.saveStatus(cha);

			} else if (monster.get(0).getMonHp() > 0) { // 처치 못 했을 때
				System.out.println(monster.get(0).toString());
				System.out.println(monster.get(0).getMonName() + " 이(가) 공격했습니다.");
				cha.setHp(cha.getHp() - monster.get(0).getMonAtk());
				System.out.println("┌─────────┐");
				System.out.println("    "+monster.get(0).getMonAtk());
				System.out.println("└─────────┘");
				System.out.println("========================");
				System.out.println("현재 체력: " + cha.getHp());
				System.out.println("========================");
				cService.saveStatus(cha);
				playSkill(cha, monster, maxLevel, maxExp, still, mana, 1);

				if (cha.getHp() <= 0) { // 사망 시 패널티
					System.out.println("캐릭터가 사망했습니다.");
					System.out.println(" 몬스터들에게 "+still+"원을 강탈 당했습니다.");
					if (cha.getMoney() > still) {
						cha.setMoney(cha.getMoney() - still);

					} else if (cha.getMoney() < still) { // 가진돈이 500원보다 적다면
						cha.setMoney(0);

					}

				}

			}

		} else if (cha.getMp() < mana) {
			System.out.println(cha.getName() + " 이(가) 공격 했습니다.");
			monster.get(0).setMonHp(monster.get(0).getMonHp() - cha.getAtk());
			System.out.println("			╃^─^─^─^─^─^─^─^─^─^─^─^╄");
			System.out.println("					"+cha.getAtk()	  );
			System.out.println("			╅───────────────────╆");

			if (monster.get(0).getMonHp() <= 0) { // 처치 했을 때
				System.out.println(monster.get(0).getMonName() + " 을(를) 처치 했습니다.");
				cha.setExp(cha.getExp() + amountExp);
				cha.setMoney(cha.getMoney() + amountMoney);
				System.out.println("========================");
				System.out.println("경험치: " + (amountExp) + ", 돈: " + (amountMoney) + " 원 획득");
				expState(expState);
				System.out.println("========================");

				if (amountExp + cha.getExp() >= amountLevel) {
					amountLevel += amountLevel+maxExp;
					cService.levelUp(cha);
					cha.setExp(0);
					cService.saveStatus(cha);
					System.out.println(cha.toStatus() + "\n");

				}

				cService.saveStatus(cha);

			} else if (monster.get(0).getMonHp() > 0) { // 처치 못 했을 때
				System.out.println(monster.get(0).toString());
				System.out.println(monster.get(0).getMonName() + " 이(가) 공격했습니다.");
				cha.setHp(cha.getHp() - monster.get(0).getMonAtk());
				System.out.println("┌─────────┐");
				System.out.println("    "+monster.get(0).getMonAtk());
				System.out.println("└─────────┘");
				System.out.println("========================");
				System.out.println("현재 체력: " + cha.getHp());
				System.out.println("========================");
				cService.saveStatus(cha);
				playSkill(cha, monster, maxLevel, maxExp, still, mana, skill);

				if (cha.getHp() <= 0) { // 사망 시 패널티
					System.out.println("캐릭터가 사망했습니다.");
					System.out.println(" 몬스터들에게 " + still + "원을 강탈 당했습니다.");
					if (cha.getMoney() > still) {
						cha.setMoney(cha.getMoney() - still);

					} else if (cha.getMoney() < still) {
						cha.setMoney(0);
						
					}

				}

			}
		}
	}
	if (skill == 1 && cha.getJob() == 2) {
		if (cha.getMp() >= mana) {
			System.out.println(cha.getName() + " 이(가) \"비영승보\"를 사용 했습니다.");
			monster.get(0).setMonHp(monster.get(0).getMonHp() - ((cha.getAtk()*2)));
			cha.setMp(cha.getMp() - mana);
			System.out.println("			╃^─^─^─^─^─^─^─^─^─^─^─^╄");
			System.out.println("					"+cha.getAtk()	  );
			System.out.println("			╅───────────────────────╆");
			System.out.println("			╃^─^─^─^─^─^─^─^─^─^─^─^╄");
			System.out.println("					"+cha.getAtk()	  );
			System.out.println("			╅───────────────────────╆");

			if (monster.get(0).getMonHp() <= 0) { // 처치 했을 때
				System.out.println(monster.get(0).getMonName() + " 을(를) 처치 했습니다.");
				cha.setExp(cha.getExp() + amountExp);
				cha.setMoney(cha.getMoney() + amountMoney);
				System.out.println("========================");
				System.out.println("경험치: " + (amountExp) + ", 돈: " + (amountMoney) + " 원 획득");
				expState(expState);
				System.out.println("========================");

				if (amountExp + cha.getExp() >= amountLevel) {
					amountLevel += amountLevel+maxExp;
					cService.levelUp(cha);
					cha.setExp(0);
					cService.saveStatus(cha);
					System.out.println(cha.toStatus() + "\n");

				}
				cService.saveStatus(cha);

			} else if (monster.get(0).getMonHp() > 0) { // 처치 못 했을 때
				System.out.println(monster.get(0).toString());
				System.out.println(monster.get(0).getMonName() + " 이(가) 공격했습니다.");
				cha.setHp(cha.getHp() - monster.get(0).getMonAtk());
				System.out.println("┌─────────┐");
				System.out.println("    "+monster.get(0).getMonAtk());
				System.out.println("└─────────┘");
				System.out.println("========================");
				System.out.println("현재 체력: " + cha.getHp());
				System.out.println("========================");
				cService.saveStatus(cha);
				playSkill(cha, monster, maxLevel, maxExp, still, mana, 1);

				if (cha.getHp() <= 0) { // 사망 시 패널티
					System.out.println("캐릭터가 사망했습니다.");
					System.out.println(" 몬스터들에게 "+still+"원을 강탈 당했습니다.");
					if (cha.getMoney() > still) {
						cha.setMoney(cha.getMoney() - still);
						
					} else if (cha.getMoney() < still) { // 가진돈이 500원보다 적다면
						cha.setMoney(0);

					}

				}

			}

		} else if (cha.getMp() < mana) {
			System.out.println(cha.getName() + " 이(가) 공격 했습니다.");
			monster.get(0).setMonHp(monster.get(0).getMonHp() - cha.getAtk());
			System.out.println("			╃^─^─^─^─^─^─^─^─^─^─^─^╄");
			System.out.println("					"+cha.getAtk()	  );
			System.out.println("			╅───────────────────────╆");

			if (monster.get(0).getMonHp() <= 0) { // 처치 했을 때
				System.out.println(monster.get(0).getMonName() + " 을(를) 처치 했습니다.");
				cha.setExp(cha.getExp() + amountExp);
				cha.setMoney(cha.getMoney() + amountMoney);
				System.out.println("========================");
				System.out.println("경험치: " + (amountExp) + ", 돈: " + (amountMoney) + " 원 획득");
				expState(expState);
				System.out.println("========================");

				if (amountExp + cha.getExp() >= amountLevel) {
					amountLevel += amountLevel+maxExp;
					cService.levelUp(cha);
					cha.setExp(0);
					cService.saveStatus(cha);
					System.out.println(cha.toStatus() + "\n");

				}

				cService.saveStatus(cha);

			} else if (monster.get(0).getMonHp() > 0) { // 처치 못 했을 때
				System.out.println(monster.get(0).toString());
				System.out.println(monster.get(0).getMonName() + " 이(가) 공격했습니다.");
				cha.setHp(cha.getHp() - monster.get(0).getMonAtk());
				System.out.println("┌─────────┐");
				System.out.println("    "+monster.get(0).getMonAtk());
				System.out.println("└─────────┘");
				System.out.println("========================");
				System.out.println("현재 체력: " + cha.getHp());
				System.out.println("========================");
				cService.saveStatus(cha);
				playSkill(cha, monster, maxLevel, maxExp, still, mana, skill);

				if (cha.getHp() <= 0) { // 사망 시 패널티
					System.out.println("캐릭터가 사망했습니다.");
					System.out.println(" 몬스터들에게 " + still + "원을 강탈 당했습니다.");
					if (cha.getMoney() > still) {
						cha.setMoney(cha.getMoney() - still);

					} else if (cha.getMoney() < still) {
						cha.setMoney(0);

					}

				}

			}
		}
	}
	
	if (skill == 1 && cha.getJob() == 3) { 
		if (cha.getMp() >= mana) {
			System.out.println(cha.getName() + " 이(가) \"썬더볼트\"를 사용 했습니다.");
			monster.get(0).setMonHp(monster.get(0).getMonHp() - (cha.getAtk()+cha.getMaxMp()));
			cha.setMp(cha.getMp() - mana);
			System.out.println("			╃^─^─^─^─^─^─^─^─^─^─^─^╄");
			System.out.println("					"+cha.getAtk()+cha.getMaxHp()	  );
			System.out.println("			╅───────────────────────╆");

			if (monster.get(0).getMonHp() <= 0) { // 처치 했을 때
				System.out.println(monster.get(0).getMonName() + " 을(를) 처치 했습니다.");
				cha.setExp(cha.getExp() + amountExp);
				cha.setMoney(cha.getMoney() + amountMoney);
				System.out.println("========================");
				System.out.println("경험치: " + (amountExp) + ", 돈: " + (amountMoney) + " 원 획득");
				expState(expState);
				System.out.println("========================");

				if (amountExp + cha.getExp() >= amountLevel) {
					amountLevel += amountLevel+maxExp;
					cService.levelUp(cha);
					cha.setExp(0);
					cService.saveStatus(cha);
					System.out.println(cha.toStatus() + "\n");

				}
				cService.saveStatus(cha);

			} else if (monster.get(0).getMonHp() > 0) { // 처치 못 했을 때
				System.out.println(monster.get(0).toString());
				System.out.println(monster.get(0).getMonName() + " 이(가) 공격했습니다.");
				cha.setHp(cha.getHp() - monster.get(0).getMonAtk());
				System.out.println("┌─────────┐");
				System.out.println("    "+monster.get(0).getMonAtk());
				System.out.println("└─────────┘");
				System.out.println("========================");
				System.out.println("현재 체력: " + cha.getHp());
				System.out.println("========================");
				cService.saveStatus(cha);
				playSkill(cha, monster, maxLevel, maxExp, still, mana, skill);

				if (cha.getHp() <= 0) { // 사망 시 패널티
					System.out.println("캐릭터가 사망했습니다.");
					System.out.println(" 몬스터들에게 "+still+"원을 강탈 당했습니다.");
					if (cha.getMoney() > still) {
						cha.setMoney(cha.getMoney() - still);

					} else if (cha.getMoney() < still) { // 가진돈이 500원보다 적다면
						cha.setMoney(0);

					}

				}

			}

		} else if (cha.getMp() < mana) {
			System.out.println(cha.getName() + " 이(가) 공격 했습니다.");
			monster.get(0).setMonHp(monster.get(0).getMonHp() - cha.getAtk());
			System.out.println("			╃^─^─^─^─^─^─^─^─^─^─^─^╄");
			System.out.println("					"+cha.getAtk()	  );
			System.out.println("			╅───────────────────────╆");
			

			if (monster.get(0).getMonHp() <= 0) { // 처치 했을 때
				System.out.println(monster.get(0).getMonName() + " 을(를) 처치 했습니다.");
				cha.setExp(cha.getExp() + amountExp);
				cha.setMoney(cha.getMoney() + amountMoney);
				System.out.println("========================");
				System.out.println("경험치: " + (amountExp) + ", 돈: " + (amountMoney) + " 원 획득");
				expState(expState);
				System.out.println("========================");

				if (amountExp + cha.getExp() >= amountLevel) {
					amountLevel += amountLevel+maxExp;
					cService.levelUp(cha);
					cha.setExp(0);
					cService.saveStatus(cha);
					System.out.println(cha.toStatus() + "\n");

				}

				cService.saveStatus(cha);

			} else if (monster.get(0).getMonHp() > 0) { // 처치 못 했을 때
				System.out.println(monster.get(0).toString());
				System.out.println(monster.get(0).getMonName() + " 이(가) 공격했습니다.");
				cha.setHp(cha.getHp() - monster.get(0).getMonAtk());
				System.out.println("┌─────────┐");
				System.out.println("    "+monster.get(0).getMonAtk());
				System.out.println("└─────────┘");
				System.out.println("========================");
				System.out.println("현재 체력: " + cha.getHp());
				System.out.println("========================");
				cService.saveStatus(cha);
				playSkill(cha, monster, 20, 1000, 1000, 100, 1);

				if (cha.getHp() <= 0) { // 사망 시 패널티
					System.out.println("캐릭터가 사망했습니다.");
					System.out.println(" 몬스터들에게 " + still + "원을 강탈 당했습니다.");
					if (cha.getMoney() > still) {
						cha.setMoney(cha.getMoney() - still);

					} else if (cha.getMoney() < still) {
						cha.setMoney(0);

					}

				}

			}
		}
	}
	if (skill == 2 && cha.getJob() == 1) {
		if (cha.getMp() >= mana) {
			System.out.println(cha.getName() + " 이(가) \"금강창파\"를 사용 했습니다.");
			monster.get(0).setMonHp(monster.get(0).getMonHp() - (cha.getAtk() + (cha.getHp() * 2)));
			cha.setMp(cha.getMp() - mana);
			System.out.println("			╃^─^─^─^─^─^─^─^─^─^─^─^╄");
			System.out.println("					"+cha.getAtk() + (cha.getHp() * 2)  );
			System.out.println("			╅───────────────────────╆");

			if (monster.get(0).getMonHp() <= 0) { // 처치 했을 때
				System.out.println(monster.get(0).getMonName() + " 을(를) 처치 했습니다.");
				cha.setExp(cha.getExp() + amountExp);
				cha.setMoney(cha.getMoney() + amountMoney);
				System.out.println("========================");
				System.out.println("경험치: " + (amountExp) + ", 돈: " + (amountMoney) + " 원 획득");
				expState(expState);
				System.out.println("========================");

				if (amountExp + cha.getExp() >= amountLevel) {
					amountLevel += amountLevel+maxExp;
					cService.levelUp(cha);
					cha.setExp(0);
					cService.saveStatus(cha);
					System.out.println(cha.toStatus() + "\n");

				}
				cService.saveStatus(cha);

			} else if (monster.get(0).getMonHp() > 0) { // 처치 못 했을 때
				System.out.println(monster.get(0).toString());
				System.out.println(monster.get(0).getMonName() + " 이(가) 공격했습니다.");
				cha.setHp(cha.getHp() - monster.get(0).getMonAtk());
				System.out.println("┌─────────┐");
				System.out.println("    "+monster.get(0).getMonAtk());
				System.out.println("└─────────┘");
				System.out.println("========================");
				System.out.println("현재 체력: " + cha.getHp());
				System.out.println("========================");
				cService.saveStatus(cha);
				playSkill(cha, monster, maxLevel, maxExp, still, mana, skill);

				if (cha.getHp() <= 0) { // 사망 시 패널티
					System.out.println("캐릭터가 사망했습니다.");
					System.out.println(" 몬스터들에게 "+still+"원을 강탈 당했습니다.");
					if (cha.getMoney() > still) {
						cha.setMoney(cha.getMoney() - still);

					} else if (cha.getMoney() < still) { // 가진돈이 500원보다 적다면
						cha.setMoney(0);

					}

				}

			}

		} else if (cha.getMp() < mana) {
			System.out.println(cha.getName() + " 이(가) 공격 했습니다.");
			monster.get(0).setMonHp(monster.get(0).getMonHp() - cha.getAtk());
			System.out.println("			╃^─^─^─^─^─^─^─^─^─^─^─^╄");
			System.out.println("					"+cha.getAtk() );
			System.out.println("			╅───────────────────────╆");


			if (monster.get(0).getMonHp() <= 0) { // 처치 했을 때
				System.out.println(monster.get(0).getMonName() + " 을(를) 처치 했습니다.");
				cha.setExp(cha.getExp() + amountExp);
				cha.setMoney(cha.getMoney() + amountMoney);
				System.out.println("========================");
				System.out.println("경험치: " + (amountExp) + ", 돈: " + (amountMoney) + " 원 획득");
				expState(expState);
				System.out.println("========================");

				if (amountExp + cha.getExp() >= amountLevel) {
					amountLevel += amountLevel+maxExp;
					cService.levelUp(cha);
					cha.setExp(0);
					cService.saveStatus(cha);
					System.out.println(cha.toStatus() + "\n");

				}

				cService.saveStatus(cha);

			} else if (monster.get(0).getMonHp() > 0) { // 처치 못 했을 때
				System.out.println(monster.get(0).toString());
				System.out.println(monster.get(0).getMonName() + " 이(가) 공격했습니다.");
				cha.setHp(cha.getHp() - monster.get(0).getMonAtk());
				System.out.println("┌─────────┐");
				System.out.println("    "+monster.get(0).getMonAtk());
				System.out.println("└─────────┘");
				System.out.println("========================");
				System.out.println("현재 체력: " + cha.getHp());
				System.out.println("========================");
				cService.saveStatus(cha);
				playSkill(cha, monster, maxLevel, maxExp, still, mana, skill);
				
				if (cha.getHp() <= 0) { // 사망 시 패널티
					System.out.println("캐릭터가 사망했습니다.");
					System.out.println(" 몬스터들에게 " + still + "원을 강탈 당했습니다.");
					if (cha.getMoney() > still) {
						cha.setMoney(cha.getMoney() - still);

					} else if (cha.getMoney() < still) {
						cha.setMoney(0);

					}

				}

			}
		}
	}
	if (skill == 2 && cha.getJob() == 2) {
		if (cha.getMp() >= mana) {
			System.out.println(cha.getName() + " 이(가) \"암살!\" 을 사용 했습니다.");
			monster.get(0).setMonHp(monster.get(0).getMonHp() - ((cha.getAtk()*4)));
			cha.setMp(cha.getMp() - mana);
			System.out.println("			╃^─^─^─^─^─^─^─^─^─^─^─^╄");
			System.out.println("					"+cha.getAtk()	  );
			System.out.println("					"+cha.getAtk()	  );
			System.out.println("			╅───────────────────────╆");
			System.out.println("			╃^─^─^─^─^─^─^─^─^─^─^─^╄");
			System.out.println("					"+cha.getAtk()	  );
			System.out.println("					"+cha.getAtk()	  );
			System.out.println("			╅───────────────────────╆");

			if (monster.get(0).getMonHp() <= 0) { // 처치 했을 때
				System.out.println(monster.get(0).getMonName() + " 을(를) 처치 했습니다.");
				cha.setExp(cha.getExp() + amountExp);
				cha.setMoney(cha.getMoney() + amountMoney);
				System.out.println("========================");
				System.out.println("경험치: " + (amountExp) + ", 돈: " + (amountMoney) + " 원 획득");
				expState(expState);
				System.out.println("========================");

				if (amountExp + cha.getExp() >= amountLevel) {
					amountLevel += amountLevel+maxExp;
					cService.levelUp(cha);
					cha.setExp(0);
					cService.saveStatus(cha);
					System.out.println(cha.toStatus() + "\n");

				}
				cService.saveStatus(cha);

			} else if (monster.get(0).getMonHp() > 0) { // 처치 못 했을 때
				System.out.println(monster.get(0).toString());
				System.out.println(monster.get(0).getMonName() + " 이(가) 공격했습니다.");
				cha.setHp(cha.getHp() - monster.get(0).getMonAtk());
				System.out.println("┌─────────┐");
				System.out.println("    "+monster.get(0).getMonAtk());
				System.out.println("└─────────┘");
				System.out.println("========================");
				System.out.println("현재 체력: " + cha.getHp());
				System.out.println("========================");
				cService.saveStatus(cha);
				playSkill(cha, monster, maxLevel, maxExp, still, mana, skill);

				if (cha.getHp() <= 0) { // 사망 시 패널티
					System.out.println("캐릭터가 사망했습니다.");
					System.out.println(" 몬스터들에게 "+still+"원을 강탈 당했습니다.");
					if (cha.getMoney() > still) {
						cha.setMoney(cha.getMoney() - still);

					} else if (cha.getMoney() < still) { // 가진돈이 500원보다 적다면
						cha.setMoney(0);

					}

				}

			}

		} else if (cha.getMp() < mana) {
			System.out.println(cha.getName() + " 이(가) 공격 했습니다.");
			monster.get(0).setMonHp(monster.get(0).getMonHp() - cha.getAtk());
			System.out.println("			╃^─^─^─^─^─^─^─^─^─^─^─^╄");
			System.out.println("					" + cha.getAtk());
			System.out.println("			╅───────────────────────╆");

			if (monster.get(0).getMonHp() <= 0) { // 처치 했을 때
				System.out.println(monster.get(0).getMonName() + " 을(를) 처치 했습니다.");
				cha.setExp(cha.getExp() + amountExp);
				cha.setMoney(cha.getMoney() + amountMoney);
				System.out.println("========================");
				System.out.println("경험치: " + (amountExp) + ", 돈: " + (amountMoney) + " 원 획득");
				expState(expState);
				System.out.println("========================");

				if (amountExp + cha.getExp() >= amountLevel) {
					amountLevel += amountLevel+maxExp;
					cService.levelUp(cha);
					cha.setExp(0);
					cService.saveStatus(cha);
					System.out.println(cha.toStatus() + "\n");

				}

				cService.saveStatus(cha);

			} else if (monster.get(0).getMonHp() > 0) { // 처치 못 했을 때
				System.out.println(monster.get(0).toString());
				System.out.println(monster.get(0).getMonName() + " 이(가) 공격했습니다.");
				cha.setHp(cha.getHp() - monster.get(0).getMonAtk());
				System.out.println("┌─────────┐");
				System.out.println("    "+monster.get(0).getMonAtk());
				System.out.println("└─────────┘");

				System.out.println("========================");
				System.out.println("현재 체력: " + cha.getHp());
				System.out.println("========================");
				cService.saveStatus(cha);
				playSkill(cha, monster, maxLevel, maxExp, still, mana, skill);

				if (cha.getHp() <= 0) { // 사망 시 패널티
					System.out.println("캐릭터가 사망했습니다.");
					System.out.println(" 몬스터들에게 " + still + "원을 강탈 당했습니다.");
					if (cha.getMoney() > still) {
						cha.setMoney(cha.getMoney() - still);

					} else if (cha.getMoney() < still) {
						cha.setMoney(0);

					}

				}

			}
		}
	}
	if (skill == 2 && cha.getJob() == 3) { 
		if (cha.getMp() >= mana) {
			System.out.println(cha.getName() + " 이(가) \"블리자드\"를 사용 했습니다.");
			monster.get(0).setMonHp(monster.get(0).getMonHp() - ((cha.getAtk()*2)+(cha.getMaxMp()*2)));
			cha.setMp(cha.getMp() - mana);
			System.out.println("			╃^─^─^─^─^─^─^─^─^─^─^─^╄");
			System.out.println("					"+(cha.getAtk()*2)+(cha.getMaxMp()*2) );
			System.out.println("			╅───────────────────────╆");
			
			if (monster.get(0).getMonHp() <= 0) { // 처치 했을 때
				System.out.println(monster.get(0).getMonName() + " 을(를) 처치 했습니다.");
				cha.setExp(cha.getExp() + amountExp);
				cha.setMoney(cha.getMoney() + amountMoney);
				System.out.println("========================");
				System.out.println("경험치: " + (amountExp) + ", 돈: " + (amountMoney) + " 원 획득");
				expState(expState);
				System.out.println("========================");

				if (amountExp + cha.getExp() >= amountLevel) {
					amountLevel += amountLevel+maxExp;
					cService.levelUp(cha);
					cha.setExp(0);
					cService.saveStatus(cha);
					System.out.println(cha.toStatus() + "\n");

				}
				cService.saveStatus(cha);

			} else if (monster.get(0).getMonHp() > 0) { // 처치 못 했을 때
				System.out.println(monster.get(0).toString());
				System.out.println(monster.get(0).getMonName() + " 이(가) 공격했습니다.");
				cha.setHp(cha.getHp() - monster.get(0).getMonAtk());
				System.out.println("┌─────────┐");
				System.out.println("    "+monster.get(0).getMonAtk());
				System.out.println("└─────────┘");
				System.out.println("========================");
				System.out.println("현재 체력: " + cha.getHp());
				System.out.println("========================");
				cService.saveStatus(cha);
				playSkill(cha, monster, maxLevel, maxExp, still, mana, skill);

				if (cha.getHp() <= 0) { // 사망 시 패널티
					System.out.println("캐릭터가 사망했습니다.");
					System.out.println(" 몬스터들에게 "+still+"원을 강탈 당했습니다.");
					if (cha.getMoney() > still) {
						cha.setMoney(cha.getMoney() - still);

					} else if (cha.getMoney() < still) { // 가진돈이 500원보다 적다면
						cha.setMoney(0);

					}

				}

			}

		} else if (cha.getMp() < mana) {
			System.out.println(cha.getName() + " 이(가) 공격 했습니다.");
			monster.get(0).setMonHp(monster.get(0).getMonHp() - cha.getAtk());
			System.out.println("			╃^─^─^─^─^─^─^─^─^─^─^─^╄");
			System.out.println("					"+cha.getAtk()	  );
			System.out.println("			╅───────────────────────╆");

			if (monster.get(0).getMonHp() <= 0) { // 처치 했을 때
				System.out.println(monster.get(0).getMonName() + " 을(를) 처치 했습니다.");
				cha.setExp(cha.getExp() + amountExp);
				cha.setMoney(cha.getMoney() + amountMoney);
				System.out.println("========================");
				System.out.println("경험치: " + (amountExp) + ", 돈: " + (amountMoney) + " 원 획득");
				expState(expState);
				System.out.println("========================");

				if (amountExp + cha.getExp() >= amountLevel) {
					amountLevel += amountLevel+maxExp;
					cService.levelUp(cha);
					cha.setExp(0);
					cService.saveStatus(cha);
					System.out.println(cha.toStatus() + "\n");

				}

				cService.saveStatus(cha);

			} else if (monster.get(0).getMonHp() > 0) { // 처치 못 했을 때
				System.out.println(monster.get(0).toString());
				System.out.println(monster.get(0).getMonName() + " 이(가) 공격했습니다.");
				cha.setHp(cha.getHp() - monster.get(0).getMonAtk());
				System.out.println("┌─────────┐");
				System.out.println("    "+monster.get(0).getMonAtk());
				System.out.println("└─────────┘");
				System.out.println("========================");
				System.out.println("현재 체력: " + cha.getHp());
				System.out.println("========================");
				cService.saveStatus(cha);
				playSkill(cha, monster, maxLevel, maxExp, still, mana, skill);

				if (cha.getHp() <= 0) { // 사망 시 패널티
					System.out.println("캐릭터가 사망했습니다.");
					System.out.println(" 몬스터들에게 " + still + "원을 강탈 당했습니다.");
					if (cha.getMoney() > still) {
						cha.setMoney(cha.getMoney() - still);

					} else if (cha.getMoney() < still) {
						cha.setMoney(0);

					}

				}

			}
		}
	}
	

}
	
	
	
	
	public void expState(int exp) {
		if(exp < 10) {
			System.out.println("	□□□□□□□□□□ "+"\""+exp+"%\"");
		}else if(exp > 10 && exp <20 ){ // exp가 10보다 크고 20보다 작으면
			System.out.println("	■□□□□□□□□□ "+"\""+exp+"%\"");
		}else if(exp > 20 && exp <30) {
			System.out.println("	■■□□□□□□□□ "+"\""+exp+"%\"");
		}else if(exp > 30 && exp <40) {
			System.out.println("	■■■□□□□□□□ "+"\""+exp+"%\"");
		}else if(exp > 40 && exp <50) {
			System.out.println("	■■■■□□□□□□ "+"\""+exp+"%\"");
		}else if(exp > 50 && exp <60) {
			System.out.println("	■■■■■□□□□□ "+"\""+exp+"%\"");
		}else if(exp > 60 && exp <70) {
			System.out.println("	■■■■■■□□□□ "+"\""+exp+"%\"");
		}else if(exp > 70 && exp <80) {
			System.out.println("	■■■■■■■□□□ "+"\""+exp+"%\"");
		}else if(exp > 80 && exp <90) {
			System.out.println("	■■■■■■■■□□ "+"\""+exp+"%\"");
		}else if(exp > 90 && exp <100) {
			System.out.println("	■■■■■■■■■□ "+"\""+exp+"%\"");
		}
		
		
		
	}
	
	
	
	
}
