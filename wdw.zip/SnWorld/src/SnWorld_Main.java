import java.util.ArrayList;
import java.util.Scanner;

import minigame.Card;
import minigame.User;
import model.AcountVO;
import model.CharacterVO;
import model.MonsterVO;
import service.AcountService;
import service.CharacterService;
import service.MonsterService;

public class SnWorld_Main {

	public static void main(String[] args) {
		AcountService aService = AcountService.getInstance();
		CharacterService cService = CharacterService.getInstance();
		MonsterService mService = MonsterService.getInstance();

		System.out.println("🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳");
		System.out.println("🔳													 🔲");
		System.out.println(
				"🔳  .d8888b.                       888       888  .d88888b.  8888888b.  888      8888888b.  🔲\n"
						+ "🔳 d88P  Y88b                      888   o   888 d88P\" \"Y88b 888   Y88b 888      888  \"Y88b 🔲\n"
						+ "🔳 Y88b.                           888  d8b  888 888     888 888    888 888      888    888 🔲\n"
						+ "🔳  \"Y888b.       88888b.          888 d888b 888 888     888 888   d88P 888      888    888 🔲\n"
						+ "🔳     \"Y88b.     888 \"88b         888d88888b888 888     888 8888888P\"  888      888    888 🔲\n"
						+ "🔳       \"888     888  888         88888P Y88888 888     888 888 T88b   888      888    888 🔲\n"
						+ "🔳 Y88b  d88P     888  888         8888P   Y8888 Y88b. .d88P 888  T88b  888      888  .d88P 🔲\n"
						+ "🔳  \"Y8888P\"      888  888         888P     Y888  \"Y88888P\"  888   T88b 88888888 8888888P\"  🔲\n"
						+ "🔳													 🔲\n"
						+ "🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳🔲🔳                ");

		Scanner sc = new Scanner(System.in);

		while (true) {
			System.out.println("Sn WORLD에 오신 것을 환영합니다.");
			System.out.println("1. 로그인 | 2. 회원가입 | 3. 종료");
			System.out.print(">>> ");

			int select = 0;

			try {
				select = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("숫자만 입력해주세요.");
				continue;
			}

			if (select == 1) {
				// 로그인
				System.out.println("아이디를 입력해주세요.");
				System.out.print(">>> ");
				String id = sc.nextLine();
				System.out.println("비밀번호를 입력해주세요.");
				System.out.print(">>> ");
				String pw = sc.nextLine();

				AcountVO acount = aService.getAcount(id);
				
				//로그인 했다면 정보 불러오기 
				
				CharacterVO character = cService.getStatus(acount.getAcountNUM());
				
				if (acount.getLoginPW().equals(pw)) {
					System.out.println("\n\n\n\n\n\n\n\n\n\n");
					System.out.println("		"+acount.getAcountNM() + "님 계정으로 접속했습니다.");
					System.out.println("\n\n\n");

					while (true) {
						// 계정 생성시 스테이터스 레벨 디폴트 값 0 
						if (character.getLevel() == 0) { // 디폴트(레벨1)일 시 캐릭터 생성
							System.out.println("캐릭터를 생성 해주세요.");
							System.out.println("주의사항: 한 계정에 하나의 캐릭터만 육성 가능합니다, 한번 생성한 캐릭터는 영원한 동반자이기 때문에 닉변, 캐릭터 삭제는 불가능합니다.");
							System.out.println();
							System.out.println("================신중한 결정 해주세요================");
							System.out.println("캐릭터 이름을 입력 해주세요");
							System.out.print(">>> ");

							String name = sc.nextLine(); // 캐릭터 이름 입력받고
							character.setName(name); // 캐릭터 객체에 이름 넣고
							character.setLevel(1); // 캐릭터를 만들었으니 레벨1로 만들어줌
							character.setAcountNM(acount.getAcountNUM());
							cService.registStatus(character); // db에 insert 
							cService.saveStatus(character);	  // db에 update
							

						} else if (character.getLevel() > 0) { // 캐릭터가 있다면 게임메인
							System.out.println("==================================================================================================");
							System.out.println(character.toStatus());
							System.out.println("==================================================================================================");
							while (true) {
								System.out.println("1.사냥터 | 2. 상점 | 3. 랭킹 | 4. 정보창 | 5. 레이드 | 6.카지노 | 7.병원 | 8.세이브 | ");
								System.out.print(">>> ");
								select = 0;

								try {
									select = Integer.parseInt(sc.nextLine());
								} catch (Exception e) {
									System.out.println("숫자만 입력해주세요.");
									continue;
								}
								if (select == 1) {
									System.out.println(" ===============================");
									System.out.println("| 1. 	   초보자 사냥터		| " + "1~11");
									System.out.println("| 2.          초원		| " + "12~21");
									System.out.println("| 3.          축사		| " + "22~41");
									System.out.println("| 4.        나뭇잎 마을	 	| " + "42~");
									System.out.println("| 6.         나가기		| ");
									System.out.println(" ================================");
									System.out.print(">>> ");
									select = 0;

									try {
										select = Integer.parseInt(sc.nextLine());
									} catch (Exception e) {
										System.out.println("숫자만 입력해주세요.");
										continue;
									}
									if(select == 1 && character.getLevel() < 12 && character.getHp() > 0) { // 초보자 사냥터 
										
										while(true) {
											System.out.println("==== 초보자 사냥터 ====");
											System.out.println("┏───────────────────┓");
											System.out.println("|1. 사냥시작 | 2. 뒤로  |");
											System.out.println("┗───────────────────┛");
											System.out.print(">>> ");
											
											select = 0;
											try {
												select = Integer.parseInt(sc.nextLine());
											} catch (Exception e) {
												System.out.println("숫자만 입력해주세요.");
												continue;
											}
											
											if(select ==1) {
												ArrayList<MonsterVO> monList = new ArrayList<MonsterVO>();
												monList=mService.getMonsterList(10); // 식별번호 10까지의 몬스터들을 담음
												
												int randMon = (int) ((Math.random() * 11)-1 );
												ArrayList<MonsterVO> monster = new ArrayList<MonsterVO>(); 
												monster.add(monList.get(randMon)); //monList에서 랜덤으로 한마리 담음
												
												System.out.println("야생의 " + monster.get(0).getMonName() + " (이)가 나타났다.");
												if(monster.get(0).getMonNum() == 5 ) {
													System.out.println(" !!! 초보자 사냥터에서 가장 강한 박쥐 !!!");
												}
												System.out.println("┏───────────────────┓");
												System.out.println("|1. 공격 | 2. 도망친다  |");
												System.out.println("┗───────────────────┛");
												System.out.print(">>> ");
												select = 0;

												try {
													select = Integer.parseInt(sc.nextLine());
												} catch (Exception e) {
													System.out.println("숫자만 입력해주세요.");
													continue;
												}

												if (select == 1) { // 싸운다
													while(true) {
														System.out.println("┏───────────────────┓");
														System.out.println("|1. 공격 | 2. 스킬	    |");
														System.out.println("┗───────────────────┛");
													System.out.print(">>> ");
													select = 0;

													try {
														select = Integer.parseInt(sc.nextLine());
													} catch (Exception e) {
														System.out.println("숫자만 입력해주세요.");
														continue;
													}
														
													if(select == 1) {
														mService.playBattle1(character, monster, 10);
														break;
													}else if(select ==2) {
														System.out.println("==================================================================================================");
														System.out.println("레벨이 낮아 접근할 수 없습니다");
														System.out.println("==================================================================================================");
													}
														
														
													}
													
													

												}else if(select ==2) { 
													System.out.println("==================================================================================================");
													System.out.println("무사히 도망쳤습니다.");
													System.out.println("==================================================================================================");
													continue;
												}
												
												
												
											}else if(select ==2) { //뒤로
												break;
											}
											
											
										}
										
										
									}else if(select ==2 && character.getLevel() >11 && character.getLevel() <22 && character.getHp() > 0) { // 초원 
										
										while(true) {
											System.out.println("====  초원  필드 ====");
											System.out.println("┏───────────────────┓");
											System.out.println("|1. 사냥시작 | 2. 뒤로  |");
											System.out.println("┗───────────────────┛");
											System.out.print(">>> ");
											
											select = 0;
											try {
												select = Integer.parseInt(sc.nextLine());
											} catch (Exception e) {
												System.out.println("숫자만 입력해주세요.");
												continue;
											}
											
											
										if(select == 1) { // 사냥
											
											ArrayList<MonsterVO> monList = new ArrayList<MonsterVO>();
											monList=mService.getMonsterList2(10, 21);
											
											int randMon =(int) ((Math.random() * 11)-1 );
											
											ArrayList<MonsterVO> monster = new ArrayList<MonsterVO>(); 
											monster.add(monList.get(randMon));
											
											System.out.println("야생의 " + monster.get(0).getMonName() + " (이)가 나타났다.");
											if(monster.get(0).getMonNum() == 15 ) {
												System.out.println(" !!! 하이에나 주의 !!!");
											}
											System.out.println("┏───────────────────┓");
											System.out.println("|1. 공격 | 2. 도망친다  |");
											System.out.println("┗───────────────────┛");
											System.out.print(">>> ");
											select = 0;

											try {
												select = Integer.parseInt(sc.nextLine());
											} catch (Exception e) {
												System.out.println("숫자만 입력해주세요.");
												continue;
											}
											
											if (select == 1) {
												while (true) {
													System.out.println("┏───────────────────┓");
													System.out.println("|1. 공격 | 2. 스킬	    |");
													System.out.println("┗───────────────────┛");
													System.out.print(">>> ");
													select = 0;

													try {
														select = Integer.parseInt(sc.nextLine());
													} catch (Exception e) {
														System.out.println("숫자만 입력해주세요.");
														continue;
													}
													if (select == 1) {
														mService.playBattle2(character, monster, 20, 1000, 1000);
														break;
														
													} else if (select == 2 && character.getMp() > 0) {

														if (character.getJob() == 1) {
															System.out.println("┏───────────────────┓");
															System.out.println("|1. 바람의상처			|");
															System.out.println("┗───────────────────┛");
															System.out.print(">>> ");
															select = 0;
															select = 0;

															try {
																select = Integer.parseInt(sc.nextLine());
															} catch (Exception e) {
																System.out.println("1을 입력해주세요.");
																continue;
															}

															mService.playSkill(character, monster, 20, 1000, 1000, 100, select);
															
														} else if (character.getJob() == 2) {
															System.out.println("┏───────────────────┓");
															System.out.println("|1. 비영승보			|");
															System.out.println("┗───────────────────┛");
															System.out.print(">>> ");
															select = 0;

															try {
																select = Integer.parseInt(sc.nextLine());
															} catch (Exception e) {
																System.out.println("1을 입력해주세요.");
																continue;
															}
															
															mService.playSkill(character, monster, 20, 1000, 1000, 80, select);
															break;
															
															
														} else if (character.getJob() == 3) {
															System.out.println("┏───────────────────┓");
															System.out.println("|1. 썬더볼트			|");
															System.out.println("┗───────────────────┛");
															System.out.print(">>> ");
															select = 0;

															try {
																select = Integer.parseInt(sc.nextLine());
															} catch (Exception e) {
																System.out.println("1을 입력해주세요.");
																continue;
															}
															
															mService.playSkill(character, monster, 20, 1000, 1000, 30, select);
															
															
														}

													}

												}
													
												
												
												
												
											}else if(select ==2) {
												System.out.println("==================================================================================================");
												System.out.println("무사히 도망쳤습니다.");
												System.out.println("==================================================================================================");
												continue;
											}

											
											
										}else if(select ==2) { //뒤로
											break;
										}
										
										}// 초원 내부 while	
										
									}else if(select == 3 && character.getLevel() >21 && character.getLevel() <42 && character.getHp() > 0) { //  축사
										ArrayList<MonsterVO> monList = new ArrayList<MonsterVO>();
										monList=mService.getMonsterList2(20, 31); 
										
	                                    int randMon = (int) ((Math.random() * 11)-1 );
										
										ArrayList<MonsterVO> monster = new ArrayList<MonsterVO>(); 
										monster.add(monList.get(randMon));
										
										System.out.println("야생의 " + monster.get(0).getMonName() + " (이)가 나타났다.");
										if(monster.get(0).getMonNum() == 26 ) {
											System.out.println(" !!! 커멘더 지코 등장 !!!");
											System.out.println(" 별풍을 쏘세요");
										}
										System.out.println("┏───────────────────┓");
										System.out.println("|1. 공격 | 2. 도망친다  |");
										System.out.println("┗───────────────────┛");
										System.out.print(">>> ");
										select = 0;

										try {
											select = Integer.parseInt(sc.nextLine());
										} catch (Exception e) {
											System.out.println("숫자만 입력해주세요.");
											continue;
										}
										
										if (select == 1) {
											while (true) {
												System.out.println("┏───────────────────┓");
												System.out.println("|1. 공격 | 2. 스킬	    |");
												System.out.println("┗───────────────────┛");
												System.out.print(">>> ");
												select = 0;

												try {
													select = Integer.parseInt(sc.nextLine());
												} catch (Exception e) {
													System.out.println("숫자만 입력해주세요.");
													continue;
												}
												if (select == 1) {
													mService.playBattle2(character, monster, 30, 3500, 3000);
													break;
													
												} else if (select == 2 && character.getMp() > 0) {

													if (character.getJob() == 1) {
														System.out.println("┏───────────────────────────┓");
														System.out.println("|1. 바람의상처 | 2. 금강창파      |");
														System.out.println("┗───────────────────────────┛");
														System.out.print(">>> ");
														select = 0;

														try {
															select = Integer.parseInt(sc.nextLine());
														} catch (Exception e) {
															System.out.println("숫자를 입력해주세요.");
															continue;
														}
														
														if(select ==1) {
															mService.playSkill(character, monster, 30, 3500, 30000, 100, select);
															break;
														}else if(select==2) {
															mService.playSkill(character, monster, 30, 3500, 30000, 300, select);
															break;
														}
														
													} else if (character.getJob() == 2) {
														System.out.println("┏───────────────────────────┓");
														System.out.println("|1. 비영승보 | 2. 암살          |");
														System.out.println("┗───────────────────────────┛");
														System.out.print(">>> ");
														select = 0;

														try {
															select = Integer.parseInt(sc.nextLine());
														} catch (Exception e) {
															System.out.println("숫자를 입력해주세요.");
															continue;
														}
														
														if(select == 1) {
															mService.playSkill(character, monster, 30, 3500, 30000, 80, select);
															break;
														}else if(select ==2) {
															mService.playSkill(character, monster, 30, 3500, 30000, 240, select);
															break;
														}
														
													} else if (character.getJob() == 3) {
														System.out.println("┏───────────────────────────┓");
														System.out.println("|1. 썬더볼트 | 2. 블리자드       |");
														System.out.println("┗───────────────────────────┛");
														System.out.print(">>> ");
														select = 0;

														try {
															select = Integer.parseInt(sc.nextLine());
														} catch (Exception e) {
															System.out.println("숫자를 입력해주세요.");
															continue;
														}
														if(select == 1) {
															mService.playSkill(character, monster, 30, 3500, 30000, 30, select);
															break;
														}else if(select ==2) {
															mService.playSkill(character, monster, 30, 3500, 30000, 150, select);
															break;
														}
														
														
													}

												}

											}
												
											
										}else if(select ==2) {
											System.out.println("==================================================================================================");
											System.out.println("무사히 도망쳤습니다.");
											System.out.println("==================================================================================================");
											continue;
										}
										
									}else if(select == 4) { // 나뭇잎 마을
										ArrayList<MonsterVO> monList = new ArrayList<MonsterVO>();
										monList=mService.getMonsterList2(30, 40); 
										
										int randMon = (int) ((Math.random() * 11)-1 );
										
										ArrayList<MonsterVO> monster = new ArrayList<MonsterVO>(); 
										monster.add(monList.get(randMon));
										
										System.out.println("야생의 " + monster.get(0).getMonName() + " (이)가 나타났다.");
										if(monster.get(0).getMonNum() == 36 ) {
											System.out.println(" !!! 나선환 !!!");
										}
										System.out.println("┏───────────────────┓");
										System.out.println("|1. 공격 | 2. 도망친다  |");
										System.out.println("┗───────────────────┛");
										System.out.print(">>> ");
										select = 0;

										try {
											select = Integer.parseInt(sc.nextLine());
										} catch (Exception e) {
											System.out.println("숫자만 입력해주세요.");
											continue;
										}
										
										if (select == 1) {
											while (true) {
												System.out.println("┏───────────────────┓");
												System.out.println("|1. 공격 | 2. 스킬	    |");
												System.out.println("┗───────────────────┛");
												System.out.print(">>> ");
												select = 0;

												try {
													select = Integer.parseInt(sc.nextLine());
												} catch (Exception e) {
													System.out.println("숫자만 입력해주세요.");
													continue;
												}
												if (select == 1) {
													mService.playBattle2(character, monster, 40, 4000, 50000);
													break;
													
												} else if (select == 2 && character.getMp() > 0) {

													if (character.getJob() == 1) {
														System.out.println("┏───────────────────────────┓");
														System.out.println("|1. 바람의상처 | 2. 금강창파      |");
														System.out.println("┗───────────────────────────┛");
														System.out.print(">>> ");
														select = 0;

														try {
															select = Integer.parseInt(sc.nextLine());
														} catch (Exception e) {
															System.out.println("숫자를 입력해주세요.");
															continue;
														}
														
														if(select ==1) {
															mService.playSkill(character, monster, 40, 4000, 50000, 100, select);
															break;
														}else if(select==2) {
															mService.playSkill(character, monster, 40, 4000, 50000, 300, select);
															break;
														}
														
													} else if (character.getJob() == 2) {
														System.out.println("┏───────────────────────────┓");
														System.out.println("|1. 비영승보 | 2. 암살          |");
														System.out.println("┗───────────────────────────┛");
														System.out.print(">>> ");
														select = 0;

														try {
															select = Integer.parseInt(sc.nextLine());
														} catch (Exception e) {
															System.out.println("숫자를 입력해주세요.");
															continue;
														}
														
														if(select == 1) {
															mService.playSkill(character, monster, 40, 4000, 50000, 80, select);
															break;
														}else if(select ==2) {
															mService.playSkill(character, monster, 40, 4000, 50000, 240, select);
															break;
														}
														
													} else if (character.getJob() == 3) {
														System.out.println("┏───────────────────────────┓");
														System.out.println("|1. 썬더볼트 | 2. 블리자드       |");
														System.out.println("┗───────────────────────────┛");
														System.out.print(">>> ");
														select = 0;

														try {
															select = Integer.parseInt(sc.nextLine());
														} catch (Exception e) {
															System.out.println("숫자를 입력해주세요.");
															continue;
														}
														if(select == 1) {
															mService.playSkill(character, monster, 40, 4000, 50000, 30, select);
															break;
														}else if(select ==2) {
															mService.playSkill(character, monster, 40, 4000, 50000, 150, select);
															break;
														}
														
														
													}

												}

											}
												
											
										}else if(select ==2) {
											System.out.println("==================================================================================================");
											System.out.println("무사히 도망쳤습니다.");
											System.out.println("==================================================================================================");
											continue;
										}
										
										
										
									}else if(select == 55555) { // 히든필드
										System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n==================================================================================================");
										System.out.println("        어케했노..! ");
										System.out.println("\"히든 필드\"에 입장 하셨습니다.");
										System.out.println("==================================================================================================");
										
										
									}else if(select == 6 && character.getLevel() > 31) {	// 닌자 저택
										
										ArrayList<MonsterVO> monList = new ArrayList<MonsterVO>();
										monList=mService.getMonsterList2(30, 41); 
										
										int randMon =(int) ((Math.random() * 11)-1 );
										
										ArrayList<MonsterVO> monster = new ArrayList<MonsterVO>(); 
										monster.add(monList.get(randMon));
										
										System.out.println("야생의 " + monster.get(0).getMonName() + " (이)가 나타났다.");
										System.out.println("┏───────────────────┓");
										System.out.println("|1. 공격 | 2. 도망친다  |");
										System.out.println("┗───────────────────┛");
										System.out.print(">>> ");
										select = 0;

										try {
											select = Integer.parseInt(sc.nextLine());
										} catch (Exception e) {
											System.out.println("숫자만 입력해주세요.");
											continue;
										}
										
										
									}else if(select == 7) { // 나가기 
										
										System.out.println("사냥터에서 나갑니다.");
										break;
										
									}else {
										System.out.println("==================================================================================================");
										System.out.println("레벨 제한으로 인해 입장할 수 없습니다.");
										System.out.println("==================================================================================================");
										continue;
									}
									
								}else if(select ==2) {
									
									System.out.println("==================================================================================================");
									System.out.println("	상점에 입장 하셨습니다.");
									System.out.println("|1. 성장 레스토랑 || 3. 나가기 |");
									System.out.println("==================================================================================================");
									System.out.print(">>> ");
									select = 0;

									try {
										select = Integer.parseInt(sc.nextLine());
									} catch (Exception e) {
										System.out.println("숫자만 입력해주세요.");
										continue;
									}
									
									if(select == 1) { // 스탯 
										
										cService.shop(character);
										System.out.println("가진 돈: "+character.getMoney());
										System.out.print(">>> ");
										select = 0;

										try {
											select = Integer.parseInt(sc.nextLine());
										} catch (Exception e) {
											System.out.println("숫자만 입력해주세요.");
											continue;
										}
										
										
										if(select ==1 ) {
											if(character.getLevel() <= 11) {
												cService.buyHp(character,500,50);
												cService.saveStatus(character);
											}else if(character.getLevel() <=21) {
												cService.buyHp(character,10000,80);
												cService.saveStatus(character);
											}else if(character.getLevel() <= 31) {
												cService.buyHp(character,100000,150);
												cService.saveStatus(character);
											}else if(character.getLevel() <= 41) {
												cService.buyHp(character,200000,300);
												cService.saveStatus(character);
											}else if(character.getLevel() <= 51) {
												cService.buyHp(character,500000,700);
												cService.saveStatus(character);
											}
											
										}else if(select ==2 ){
											if(character.getLevel() <= 11) {
												cService.buyMp(character,500,50);
												cService.saveStatus(character);
											}else if(character.getLevel() <=21) {
												cService.buyMp(character,10000,80);
												cService.saveStatus(character);
											}else if(character.getLevel() <= 31) {
												cService.buyMp(character,100000,150);
												cService.saveStatus(character);
											}else if(character.getLevel() <= 41) {
												cService.buyMp(character,200000,300);
												cService.saveStatus(character);
											}else if(character.getLevel() <= 51) {
												cService.buyMp(character,500000,700);
												cService.saveStatus(character);
											}
										}else if(select ==3) {
											if(character.getLevel() <= 11) {
												cService.buyAtk(character,500,10);
												cService.saveStatus(character);
											}else if(character.getLevel() <= 21) {
												cService.buyAtk(character,10000,30);
												cService.saveStatus(character);
											}else if(character.getLevel() <= 31) {
												cService.buyAtk(character,100000,70);
												cService.saveStatus(character);
											}else if(character.getLevel() <= 41) {
												cService.buyAtk(character,200000,100);
												cService.saveStatus(character);
											}else if(character.getLevel() <= 51) {
												cService.buyAtk(character,500000,500);
												cService.saveStatus(character);
											}
										}else if(select ==4) {
											System.out.println("레스토랑에서 나갑니다.");
											break;
										}
										
										
										
									}else if(select ==22) { 
										System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n==================================================================================================");
										System.out.println("       어케했노..! ");
										System.out.println("\"히든 상점\"에 입장 하셨습니다.");
										System.out.println("==================================================================================================");
										System.out.println("|1. Lv | 2. ATK   |");
										System.out.println("|3. Hp | 4. MONEY | 5.exit");
										System.out.println("┏━━━━━━━━━━━━━━━━━━━━┓");
										System.out.println("┃                    ┓");
										System.out.println("┃                    ┃");
										System.out.println("┃                    ┃");
										System.out.println("┃    1          2    ┃");
										System.out.println("┃                    ┃");
										System.out.println("┃    3          4    ┃");
										System.out.println("┃                    ┃");
										System.out.println("┃                    ┃");
										System.out.println("┃                    ┃");
										System.out.println("┃                    ┃");
										System.out.println("┃                    ┃");
										System.out.println("┃                    ┃");
										System.out.println("┃                    ┃");
										System.out.println("┃             ┏━━━━━━┃");
										System.out.println("┖━━━━━━━━━━━━━━━━━━━━┚");
										System.out.print(">>> ");
										select = 0;

										try {
											select = Integer.parseInt(sc.nextLine());
										} catch (Exception e) {
											System.out.println("숫자만 입력해주세요.");
											continue;
										}
										if(select ==1) {
											cService.levelUp(character);
											cService.levelUp(character);
											cService.levelUp(character);
											cService.levelUp(character);
											cService.levelUp(character);
											System.out.println("레벨 5 증가");
											continue;
										}
										else if(select == 2) {
											character.setAtk(character.getAtk() + 100);
											System.out.println("공격력 100 증가");
											continue;
										}else if(select == 3) {
											character.setMaxHp(character.getMaxHp() + 200);
											character.setHp(character.getMaxHp());
											System.out.println("체력 200 증가");
											continue;
										}else if(select == 4) {
											character.setMoney(character.getMoney() + 500000);
											System.out.println("500,000원 획득");
											continue;
										}else if(select ==5) {
											break;
										}
										
										
									}else if(select ==3) {
										System.out.println("다음에 또 오세요~");
										break;
									}
									
								}else if(select ==3) {
									ArrayList<CharacterVO> rankList = new ArrayList<CharacterVO>();
									rankList.addAll(cService.levelList());
									
									System.out.println("==================================================================================================");
									for(int i = 0; i < rankList.size(); i++) {
										System.out.println("                   "+(i+1) + "위 " 
													+ rankList.get(i).toString());
									}
									System.out.println("==================================================================================================");
									
									
									
								}else if(select == 4) {
									System.out.println("==================================================================================================");
									System.out.println(character.toStatus());
									System.out.println("==================================================================================================");
								}else if (select == 5) {
									cService.saveStatus(character);
									System.out.println("==================================================================================================");
									System.out.println("					던전에 입장 하셨습니다.");
									System.out.println("==================================================================================================");
									System.out.println("|1.들어간다 | 2. 도망간다");
									select = 0;

									try {
										select = Integer.parseInt(sc.nextLine());
									} catch (Exception e) {
										System.out.println("숫자만 입력해주세요.");
										continue;
									}
									
									if(select ==1) {
										System.out.println("⠀⠀⠀⡀⠀⠤⠄⠒⠂⠀⠉⠉⠉⠉⠉⠀⠢⢄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
												+ "⠀⠀⡠⠊⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠑⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
												+ "⠀⢰⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠄⠀⠀⠀⠀⠀⠀⠀⠀\n"
												+ "⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠆⠀⠀⠀⠀⠀⠀⠀\n"
												+ "⠀⠰⠀⠀⡌⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠀⠠⠀⢸⠀⠀⠀⠀⠀⠀⠀\n"
												+ "⠀⠀⢆⠀⢟⣀⠤⠷⡀⠀⠀⡀⠒⠄⣀⠀⠀⡠⠔⠉⠉⡇⠘⡄⠀⠀⠀⠀⠀⠀          돌아가라 휴먼.\n"
												+ "⠀⠀⢸⠀⠀⠀⠸⠀⠑⠐⠉⠀⠀⠀⠀⠈⠉⠀⠀⠀⠀⡇⠀⠈⠆⠀⠀⠀⠀⠀\n"
												+ "⠀⠀⢸⠀⡄⠀⠇⠀⠀⠀⠀⠀⠀⠀⠀⢀⠤⠒⠀⠢⠀⡇⠀⠀⢰⠀⠀⠀⠀⠀\n"
												+ "⠀⠀⢘⠀⠀⢸⠀⠀⠊⢁⣀⡈⠑⠀⠀⠑⠾⠁⠀⠀⠀⣇⠀⠀⠈⡆⠀⠀⠀⠀\n"
												+ "⠀⠀⠘⡀⢀⠘⡀⠀⠀⠀⠛⢉⣴⣴⣶⣄⠀⠀⠀⠀⠀⠀⠱⡄⠀⠡⡀⠀⠀⠀\n"
												+ "⠀⠀⢠⠁⢁⠌⠀⠀⠀⠀⠀⠘⣿⣿⣿⣿⠆⠀⠀⠀⠀⠀⠀⠘⡀⠀⠈⢂⠀⠀\n"
												+ "⠀⠀⢃⠀⡈⠀⠀⠀⠀⠀⠀⠀⠈⠛⠛⠋⡀⡀⠄⠀⠀⠀⠀⠀⠇⠀⣀⠌⠀⠀\n"
												+ "⠀⠀⠈⢆⢇⠀⠀⠀⠀⠀⠀⠈⠁⠖⢲⡖⡏⠀⠀⠀⠀⠀⢀⡘⣀⠠⠃⠀⠀⠀\n"
												+ "⠀⠀⠀⠀⠀⠠⣀⠀⠀⠀⠀⠀⠀⠀⠊⠉⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀\n"
												+ "⠀⠀⠀⠀⠀⠀⠀⠉⠀⠂⠠⡤⠄⠀⠀⠀⠤⠴⠐⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
												+ "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣧⣄⣀⠀⠀⠀⣰⣾⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀\n"
												+ "⠀⠀⠀⠀⠀⠀⠀⣠⣴⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣤⠄⡀⠀⠀⠀\n"
												+ "⠀⠀⠀⠀⠀⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣟⣿⣿⣿⣿⣻⣿⣿⣿⣷⣤⠁⠢⠀\n"
												+ "⠀⠀⠀⠀⠠⢡⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⣿⣧⣿⣿⡟⣹⣿⣿⣿⣿⣷⡄⠀\n"
												+ "⠀⠀⠀⠠⠁⢸⣿⣿⣿⣹⣿⣿⣿⣿⣿⣿⡇⣿⣿⣿⣿⣿⣿⣿⣿⣟⣿⣿⣿⡄\n"
												+ "⠀⠀⢀⠃⠀⢸⣿⣿⢧⣿⣿⣿⣿⣿⣿⣿⣧⡿⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷\n"
												+ "⠀⠀⠆⠀⠀⠘⣷⣯⣿⣿⣿⣿⠿⠿⠿⠛⠛⠋⠉⠉⠉⠉⠉⠛⠛⠛⠿⠿⠿⠿\n"
												+ "⠀⠸⠀⠀⠀⠀⠉⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
										System.out.println( "＿人人人人人人人人＿\n"
														+ "＞　　보스 등장 　＜\n"
														+ "￣^Y^Y^Y^Y^Y^Y^Y￣\n"
														+ "");
										
										System.out.println("==================================================================================================");
										System.out.println("도우너의 스킬 \"강퇴\" 발동");
										System.out.println("==================================================================================================");
										System.out.println("던전에서 강퇴 당했습니다.");
										break;
										
										
									}else if(select ==2) {
										System.out.println("▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄\n"
														 + "████▌▄▌▄▐▐▌█████\n"
														 + "████▌▄▌▄▐▐▌▀████\n"
														 + "▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀\n"
														 + "");
										System.out.println("던전을 나왔습니다.");
										break;
									}
									
									
									
								}else if(select == 6) {
									System.out.println("==================================================================================================");
									System.out.println("					카지노에 입장 하셨습니다.");
									System.out.println("==================================================================================================");
									System.out.println("참여 1번 나가기 2번");
									System.out.print(">>> ");
									select = 0;

									try {
										select = Integer.parseInt(sc.nextLine());
									} catch (Exception e) {
										System.out.println("숫자만 입력해주세요.");
										continue;
									}
									
									if(select == 1) {
										if(character.getMoney() <= 0) { // 가진돈이 0과 같거나 0보다 적다면
											System.out.println("\n\n\n\n\n");
											System.out.println("카지노 딜러: 그지는 가라.");
											System.out.println(character.getName() +"이 카지노에서 쫓겨났습니다.");
											break;
										}
										
										else {
										Card.cardRule();
										System.out.println("\n\n\n\n");
										Card cd = new Card();
										
										Card.backCard();
										
										User play1 = new User(character.getName(), character.getAcountNM(), character.getMoney());
										
										int betMoney;
										
										System.out.print("배팅 금액을 입력 해주세요: ");
										try {
											betMoney = Integer.parseInt(sc.nextLine());
										} catch (Exception e) {
											System.out.println("숫자만 입력해주세요.");
											continue;
										}
										
										if(betMoney > character.getMoney()) { //배팅 금액이 소유금액보다 크다면 
											System.out.println("\n\n\n\n\n");
											System.out.println("카지노 딜러: 그지는 가라.");
											System.out.println(character.getName() +"이 카지노에서 쫓겨났습니다.");
											break;
										
										}
										else {
											
											character.setMoney(character.getMoney()-betMoney);
											
											System.out.println("당신의 선택은?");
											System.out.println("| 1.승 | 2.무 | 3.패 | 4.나가기 |");
											System.out.print(">>> ");
											select = 0;

											try {
												select = Integer.parseInt(sc.nextLine());
											} catch (Exception e) {
												System.out.println("숫자만 입력해주세요.");
												continue;
											}
											
											play1.setCard((int) (Math.random() * 8 + 2)); 
											
											int comCard = (int) (Math.random() * 8 + 2);
											
											
											if(select == 1) { // 유저의 카드가 이길 때 배팅머니 2배 
												if(play1.getCard() > comCard) { // 유저가 맞았을 때 
													System.out.println("			\"축하 드립니다.\"			"); 
													System.out.println("====================" +character.getName()+" 님의 카드====================");
													Card.printCard(play1.getCard());
													System.out.println("====================" +"딜러"+"  의 카드====================");
													Card.printCard(comCard);
													System.out.println("\n");
													character.setMoney(character.getMoney() +(betMoney * 2));
													play1.toStatus();
													cService.saveStatus(character);
													System.out.println(betMoney+" 원 배팅");
													System.out.println("Money: "+character.getMoney());
													
													
													
													
												}else {
													System.out.println("			\"틀렸습니다 ㅋㅋ 딜러 승\"			"); 
													System.out.println("====================" +character.getName()+" 님의 카드====================");
													Card.printCard(play1.getCard());
													System.out.println("====================" +"딜러"+"  의 카드====================");
													Card.printCard(comCard);
													System.out.println("\n");
													play1.toStatus();
													cService.saveStatus(character);
													System.out.println(betMoney+" 원 배팅");
													System.out.println("Money: "+character.getMoney());
												}
												
											}else if(select == 2 ){ // 비겼을 때 배팅머니 3배 
												if(play1.getCard() == comCard) { // 유저가 맞았을 때 
													System.out.println("			\"축하 드립니다.\"			"); 
													System.out.println("====================" +character.getName()+" 님의 카드====================");
													Card.printCard(play1.getCard());
													System.out.println("====================" +"딜러"+"  의 카드====================");
													Card.printCard(comCard);
													System.out.println("\n");
													character.setMoney(character.getMoney() +(betMoney * 2));
													play1.toStatus();
													cService.saveStatus(character);
													System.out.println(betMoney+" 원 배팅");
													System.out.println("Money: "+character.getMoney());
													
												}else {
													System.out.println("			\"틀렸습니다 ㅋㅋ 딜러 승\"			"); 
													System.out.println("====================" +character.getName()+" 님의 카드====================");
													Card.printCard(play1.getCard());
													System.out.println("====================" +"딜러"+"  의 카드====================");
													Card.printCard(comCard);
													System.out.println("\n");
													play1.toStatus();
													cService.saveStatus(character);
													System.out.println(betMoney+" 원 배팅");
													System.out.println("Money: "+character.getMoney());
												}
												
											}else if(select == 3) { // 유저의 카드가 졌을 때 배팅머니 2배 
												if(play1.getCard() < comCard) { // 유저가 맞았을 때 
													System.out.println("			\"축하 드립니다.\"			"); 
													System.out.println("====================" +character.getName()+" 님의 카드====================");
													Card.printCard(play1.getCard());
													System.out.println("====================" +"딜러"+"  의 카드====================");
													Card.printCard(comCard);
													System.out.println("\n");
													character.setMoney(character.getMoney() +(betMoney * 2));
													play1.toStatus();
													cService.saveStatus(character);
													System.out.println(betMoney+" 원 배팅");
													System.out.println("Money: "+character.getMoney());
													
												}else {
													System.out.println("			\"틀렸습니다 ㅋㅋ 딜러 승\"			"); 
													System.out.println("====================" +character.getName()+" 님의 카드====================");
													Card.printCard(play1.getCard());
													System.out.println("====================" +"딜러"+"  의 카드====================");
													Card.printCard(comCard);
													System.out.println("\n");
													play1.toStatus();
													cService.saveStatus(character);
													System.out.println(betMoney+" 원 배팅");
													System.out.println("Money: "+character.getMoney());
												}
											}else if(select ==4 ) { // 도박장을 나갔을 때 
												System.out.println("카지노 딜러: 쫄보라서 도망치나?");
												character.setMoney(character.getMoney()+betMoney); // 베팅한 금액만큼 다시 돌려주기
												cService.saveStatus(character);
												break;
											}
											
											
										}
										
										}
										
									}else if(select == 2) {
										break;
									}
									
									
									
									
									
								}else if(select == 7) {
									character.setHp(character.getMaxHp());
									character.setMp(character.getMaxMp());
									System.out.println("==================================================================================================");
									System.out.println("					병원에서 Hp/Mp를 회복 하셨습니다.");
									System.out.println("HP: "+character.getMaxHp()+ "/" + character.getHp());
									System.out.println("MP: "+character.getMaxMp()+ "/" + character.getMp());
									System.out.println("==================================================================================================");
									
								}else if(select == 8) {
									cService.saveStatus(character);
									System.out.println("세이브 했습니다");
									
								}

							}

						}

			
					}
				}

			} else if (select == 2) { // 회원가입
				System.out.println("아이디를 입력해주세요.");
				System.out.print(">>> ");
				String id = sc.nextLine();
				System.out.println("비밀번호를 입력해주세요.");
				String pw = sc.nextLine();
				System.out.print(">>> ");
				System.out.println("성함을 입력해주세요.");
				String name = sc.nextLine();
				System.out.print(">>> ");

				aService.registAcount(id, pw, name); // DB에 회원등록
				
			} else if (select == 3) {
				System.out.println("종료 합니다.");
				break;
			}

		}

	} // 메인의 끝
}
