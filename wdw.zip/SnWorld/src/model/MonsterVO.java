package model;

public class MonsterVO {
	private String monName; // 몬스터의 이름
	private int monHp;		// 몬스터의 체력
	private int monAtk; 	// 몬스터의 공격력
	private int monExp;		// 몬스터가 주는 경험치
	private int monMoney;	// 몬스터가 주는 돈
	private int monNum;
	
	public MonsterVO() {
		
	}
	

	@Override
	public String toString() {
		return "몬스터상태 [이름= " + monName + ", 체력= " + monHp + "]";
	}
	
	public String getMonName() {
		return monName;
	}

	public void setMonName(String monName) {
		this.monName = monName;
	}

	public int getMonHp() {
		return monHp;
	}

	public void setMonHp(int monHp) {
		this.monHp = monHp;
	}

	public int getMonAtk() {
		return monAtk;
	}

	public void setMonAtk(int monAtk) {
		this.monAtk = monAtk;
	}

	public int getMonExp() {
		return monExp;
	}

	public void setMonExp(int monExp) {
		this.monExp = monExp;
	}

	public int getMonMoney() {
		return monMoney;
	}

	public void setMonMoney(int monMoney) {
		this.monMoney = monMoney;
	}


	public int getMonNum() {
		return monNum;
	}


	public void setMonNum(int monNum) {
		this.monNum = monNum;
	}

	
}
