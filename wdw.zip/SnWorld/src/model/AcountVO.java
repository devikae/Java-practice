package model;

public class AcountVO {
	private String loginID;		// 계정 ID
	private String loginPW;		// 계정 비밀번호
	private String acountNM;		// acount_name 회원명
	private int acountNUM;			// 식별 번호
	
	public AcountVO() {}
	

	public AcountVO(String loginID, String loginPW, String acountNM) {
		this.loginID = loginID;
		this.loginPW = loginPW;
		this.acountNM = acountNM;
	}
	

	@Override
	public String toString() {
		return "AcountVO [loginID=" + loginID + ", acountNM=" + acountNUM + "]";
	}

	public String getLoginID() {
		return loginID;
	}

	public void setLoginID(String loginID) {
		this.loginID = loginID;
	}

	public String getLoginPW() {
		return loginPW;
	}

	public void setLoginPW(String loginPW) {
		this.loginPW = loginPW;
	}

	public String getAcountNM() {
		return acountNM;
	}

	public void setAcountNM(String acountNM) {
		this.acountNM = acountNM;
	}

	public int getAcountNUM() {
		return acountNUM;
	}

	public void setAcountNUM(int acountNUM) {
		this.acountNUM = acountNUM;
	}

	
	
}
