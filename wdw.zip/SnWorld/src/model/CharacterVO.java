package model;

public class CharacterVO {

	private String name;	// 닉네임 
	private int level =0;		
	private int hp = 100; // 현재 체력
	private int mp =100;  // 현재 마나 		
	private int atk = 10;		// 공격력
	private int job =0;		// 직업코드 | 0: 초보자 | 1: 전사 | 2: 도적 | 3: 마법사
	private int money = 0;		// 소지금
	private int exp = 0;		// 경험치
	private int acountNM;	// Acount의 식별번호와 같게
	private int maxHp =100;
	private int maxMp =100;

	
	public CharacterVO() {}
	
	public CharacterVO(int a) {
		this.name = name;
		this.level = level;
		this.hp = hp;
		this.mp = mp;
		this.atk = atk;
		this.job = job;
		this.money = money;
		this.exp = exp;
		this.maxHp = maxHp;
		this.maxMp = maxMp;
		this.acountNM = a;
	}

	
	public CharacterVO(String name, int level, int hp, int mp, int atk, int job, int money, int exp, int acountNM,
			int maxHp, int maxMp) {
		this.name = name;
		this.level = level;
		this.hp = hp;
		this.mp = mp;
		this.atk = atk;
		this.job = job;
		this.money = money;
		this.exp = exp;
		this.acountNM = acountNM;
		this.maxHp = maxHp;
		this.maxMp = maxMp;
	}

	public String toStatus() {
		 if(job == 1){
			return "내정보  [닉네임: " + name + " | 레벨: " + level + " | HP: " + maxHp +"/" + hp + " | MP: " + maxMp+ "/" + mp + " | 전투력: " + atk
					
					+ " | 직업: " + "전사"  + " | money: " + money +"원 " +"]";
		 }else if(job == 2) {
			 return "내정보  [닉네임: " + name + " | 레벨: " + level + " | HP: " + maxHp +"/" + hp + " | MP: " + maxMp+ "/" +mp + " | 전투력: " + atk
						
						+ " | 직업: " + "도적"  + " | money: " + money +"원 " +"]";
		 }else if(job == 3) {
			 return "내정보  [닉네임: " + name + " | 레벨: " + level + " | HP: " + maxHp +"/" + hp + " | MP: " + maxMp+ "/" +mp + " | 전투력: " + atk
						
						+ " | 직업: " + "마법사"  + " | money: " + money +"원 " +"]";
		 }else {
			 return "내정보  [닉네임: " + name + " | 레벨: " + level + " | HP: " + maxHp +"/" + hp + " | MP: " + maxMp+ "/" +mp + " | 전투력: " + atk
						
						+ " | 직업: " + "초보자"  + " | money: " + money +"원 " +"]";
		 }
				
	}
	
	@Override
	public String toString() {
		if(job == 1) {
			return "[닉네임: " + name + ", 레벨: " + level + ", HP: " + maxHp + ", MP: " + maxMp + ", 공격력: " + atk
					+ ", 직업: " + "전사" + "]";
		}else if(job ==2) {
			return "[닉네임: " + name + ", 레벨: " + level + ", HP: " + maxHp + ", MP: " + maxMp + ", 공격력: " + atk
					+ ", 직업: " + "도적" + "]";
		}else if(job ==3) {
			return "[닉네임: " + name + ", 레벨: " + level + ", HP: " + maxHp + ", MP: " + maxMp + ", 공격력: " + atk
					+ ", 직업: " + "마법사" + "]";
		}else {
			return "[닉네임: " + name + ", 레벨: " + level + ", HP: " + maxHp + ", MP: " + maxMp + ", 공격력: " + atk
					+ ", 직업: " + "초보자" + "]";
		}
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}

	public int getMp() {
		return mp;
	}

	public void setMp(int mp) {
		this.mp = mp;
	}

	public int getAtk() {
		return atk;
	}

	public void setAtk(int atk) {
		this.atk = atk;
	}

	public int getJob() {
		return job;
	}

	public void setJob(int job) {
		this.job = job;
	}

	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		this.money = money;
	}

	public int getExp() {
		return exp;
	}

	public void setExp(int exp) {
		this.exp = exp;
	}

	public int getAcountNM() {
		return acountNM;
	}

	public void setAcountNM(int acountNM) {
		this.acountNM = acountNM;
	}

	public int getMaxHp() {
		return maxHp;
	}

	public void setMaxHp(int maxHp) {
		this.maxHp = maxHp;
	}

	public int getMaxMp() {
		return maxMp;
	}

	public void setMaxMp(int maxMp) {
		this.maxMp = maxMp;
	}


	
	
	
	
}
