package minigame;

import model.CharacterVO;

public class User extends CharacterVO {
	String name = super.getName();
	int AcountNM = super.getAcountNM();
	int money = super.getMoney();
	int card;
	
	public User(){};
	
	
	public User(String name, int num, int money) {
		this.name = name;
		this.AcountNM = num;
		this.money = money;
		this.card = 0;
	}
	
	

	@Override
	public String toString() {
		return "[" + name +" 님의 "+ ", money=" + money + "]";
	}
	
	void State1() {
		System.out.println(name+ "님의 보유 금액: "+ money);
	}
	
	


	public int getAcountNM() {
		return AcountNM;
	}



	public void setAcountNM(int acountNM) {
		AcountNM = acountNM;
	}



	public int getMoney() {
		return money;
	}



	public void setMoney(int money) {
		this.money = money;
	}



	public int getCard() {
		return card;
	}



	public void setCard(int card) {
		this.card = card;
	}


	
	
}
