package minigame;

public class Card {
	
	public Card(){};
	
	public static void cardRule() {
		System.out.println("\n\n			게임 규칙");
		System.out.println("	1. 시작하면 플레이어에게 2~9중 랜덤한 카드가 한장 지급됩니다. ");
		System.out.println("	2. 어떤 카드가 들어왔는지는 본인도 알 수 없으며 상대의 카드보다 숫자가 높으면 승리 ");
		System.out.println("	3. 카드\"2\"는 9카드를 이길 수 있습니다. ");
		System.out.println("	4. 승 | 무 | 패 중에 맞춰주시면 됩니다. ");
		System.out.println("	 승,패 적중 시 2배 무승부 적중 시 3배의 돈을 받으실 수 있습니다.");
	}
	
	public static void backCard() {
		System.out.println("┌───────┐      ┌───────┐ \n" +
	 			 "│ /////////// │      │ /////////// │\n" +
	 			"│ /////////// │      │ /////////// │\n" +
	 			"│ /////////// │      │ /////////// │\n" +
	 			"│ /////////// │      │ /////////// │\n" +
	 			"│ /////////// │      │ /////////// │\n" +
	 			"│ /////////// │      │ /////////// │\n" +
	 			"└───────┘      └───────┘ \n");
	}
	
	 public static void printCard(int x) {
		
		if(x == 2) {
			System.out.println("┌─────────┐       \n" +
					 "│2◆     ∧       │      \n" +
					"│       /  \\      |      \n" +
					"│      │  │     │      \n" +
					"│      │  │     │      \n" +
					"│      ┃  ┃     │      \n" +
					"│    ┢┛╂┗┪    |    \n" +
					"│       ┃┃      │      \n" +
					"│       ┃┃   ◆2│      \n" +
					"└─────────┘       \n");
				
		}else if(x == 3) {
			System.out.println
		       ("┌───────┐       \n" +
				 "│3◆          │      \n" +
				 "│             │      \n" +
				 "│             │      \n" +
				 "│             │      \n" +
				 "│             │      \n" +
				 "│          ◆3│      \n" +
				 "└───────┘       \n");
				
	
	
		}else if(x ==4) {
			System.out.println
		       ("┌───────┐       \n" +
				 "│4◆          │      \n" +
				 "│             │      \n" +
				 "│             │      \n" +
				 "│             │      \n" +
				 "│             │      \n" +
				 "│          ◆4│      \n" +
				 "└───────┘       \n");
			
	 }else if(x == 5) {
		System.out.println
		       ("┌───────┐       \n" +
				 "│5◆          │      \n" +
				 "│             │      \n" +
				 "│             │      \n" +
				 "│             │      \n" +
				 "│             │      \n" +
				 "│          ◆5│      \n" +
				 "└───────┘       \n");
	
	 }else if(x == 6) {
		System.out.println
		       ("┌───────┐       \n" +
				 "│6◆          │      \n" +
				 "│             │      \n" +
				 "│             │      \n" +
				 "│             │      \n" +
				 "│             │      \n" +
				 "│          ◆6│      \n" +
				 "└───────┘       \n");
	
	 }else if(x ==7) {
		 System.out.println
		       ("┌───────┐       \n" +
				 "│7◆          │      \n" +
				 "│             │      \n" +
				 "│             │      \n" +
				 "│             │      \n" +
				 "│             │      \n" +
				 "│          ◆7│      \n" +
				 "└───────┘       \n");
	 }else if(x == 8) {
		System.out.println
		       ("┌───────┐       \n" +
				 "│8◆          │      \n" +
				 "│             │      \n" +
				 "│             │      \n" +
				 "│             │      \n" +
				 "│             │      \n" +
				 "│          ◆8│      \n" +
				 "└───────┘       \n");
	
	 }else if(x == 9) {
		 System.out.println
		       ("┌───────┐       \n" +
				 "│9◆          │      \n" +
				 "│             │      \n" +
				 "│             │      \n" +
				 "│             │      \n" +
				 "│             │      \n" +
				 "│          ◆9│      \n" +
				 "└───────┘       \n");
	 	}
}
}

